// Enhanced Audio Player Processor with better barge-in handling
// Based on ChatGPT's suggestions for immediate audio buffer clearing

class ExpandableBuffer {
    constructor(initialLength = 32768) {
        this.buffer = new Float32Array(initialLength);
        this.writeIndex = 0;
        this.readIndex = 0;
        this.underflowedSamples = 0;
        this.lastBufferWriteTime = Date.now();
        this.isCleared = false; // Track if buffer was cleared for barge-in
    }

    write(data) {
        this.lastBufferWriteTime = Date.now();
        
        // If buffer was cleared for barge-in, ignore any remaining queued audio
        if (this.isCleared) {
            console.log('🔇 Ignoring audio write - buffer cleared for barge-in');
            return;
        }
        
        const requiredLength = this.writeIndex + data.length;
        if (requiredLength > this.buffer.length) {
            const newLength = Math.max(requiredLength, this.buffer.length * 2);
            const newBuffer = new Float32Array(newLength);
            newBuffer.set(this.buffer);
            this.buffer = newBuffer;
        }
        
        this.buffer.set(data, this.writeIndex);
        this.writeIndex += data.length;
    }

    read(requestedSamples) {
        const availableSamples = this.writeIndex - this.readIndex;
        
        // If buffer was cleared, return silence
        if (this.isCleared) {
            return new Float32Array(requestedSamples); // Return silence
        }
        
        if (availableSamples === 0) {
            this.underflowedSamples += requestedSamples;
            return new Float32Array(requestedSamples);
        }

        const samplesToRead = Math.min(requestedSamples, availableSamples);
        const result = this.buffer.subarray(this.readIndex, this.readIndex + samplesToRead);
        this.readIndex += samplesToRead;

        if (this.readIndex >= this.writeIndex) {
            this.readIndex = 0;
            this.writeIndex = 0;
        }

        if (samplesToRead < requestedSamples) {
            const paddedResult = new Float32Array(requestedSamples);
            paddedResult.set(result, 0);
            this.underflowedSamples += requestedSamples - samplesToRead;
            return paddedResult;
        }

        return result;
    }

    // ENHANCED: Immediate buffer clearing for barge-in
    clearBuffer() {
        const hadData = this.writeIndex > this.readIndex;
        console.log(`🔇 ENHANCED: Buffer cleared immediately - had ${hadData ? 'data' : 'no data'}`);
        
        // Immediate clearing
        this.buffer.fill(0); // Zero out the entire buffer
        this.writeIndex = 0;
        this.readIndex = 0;
        this.underflowedSamples = 0;
        this.isCleared = true; // Mark as cleared to ignore future writes
        
        // Reset cleared flag after a short delay to allow new audio
        setTimeout(() => {
            this.isCleared = false;
            console.log('🔇 Buffer ready for new audio after barge-in');
        }, 100);
        
        return hadData;
    }

    getStatus() {
        return {
            buffered: this.writeIndex - this.readIndex,
            underflowed: this.underflowedSamples,
            lastWrite: Date.now() - this.lastBufferWriteTime,
            isCleared: this.isCleared
        };
    }
}

class AudioPlayerProcessor extends AudioWorkletProcessor {
    constructor() {
        super();
        this.audioBuffer = new ExpandableBuffer();
        this.isPlaying = false;
        
        this.port.onmessage = (event) => {
            const { type, data } = event.data;
            
            switch (type) {
                case "audio":
                    this.audioBuffer.write(new Float32Array(data));
                    if (!this.isPlaying) {
                        this.isPlaying = true;
                        console.log('🎵 Audio playback started');
                    }
                    break;
                    
                case "barge-in":
                case "clear": // Handle both message types
                    console.log(`🔇 ENHANCED: ${type} message received - clearing buffer immediately`);
                    const hadData = this.audioBuffer.clearBuffer();
                    this.isPlaying = false;
                    
                    // Notify main thread of successful clearing
                    this.port.postMessage({
                        type: "buffer-cleared",
                        hadData: hadData,
                        timestamp: Date.now()
                    });
                    break;
                    
                case "stop":
                    console.log('🛑 Stop message received');
                    this.audioBuffer.clearBuffer();
                    this.isPlaying = false;
                    break;
                    
                case "status":
                    this.port.postMessage({
                        type: "status-response",
                        status: this.audioBuffer.getStatus()
                    });
                    break;
                    
                default:
                    console.warn(`⚠️ Unknown message type: ${type}`);
            }
        };
    }

    process(inputs, outputs, parameters) {
        const output = outputs[0];
        const outputChannel = output[0];

        if (this.isPlaying && outputChannel) {
            const audioData = this.audioBuffer.read(outputChannel.length);
            outputChannel.set(audioData);
            
            // Check if we've run out of audio
            if (this.audioBuffer.getStatus().buffered === 0 && this.isPlaying) {
                this.isPlaying = false;
                console.log('🎵 Audio playback completed');
            }
        }

        return true;
    }
}

registerProcessor("audio-player-processor", AudioPlayerProcessor);
