#!/usr/bin/env tsx

import 'dotenv/config';
import { createTranscribeWebSocketServer } from '../src/lib/transcribe-websocket-server';

// Start the WebSocket server
const server = createTranscribeWebSocketServer(8080);

// Handle graceful shutdown
process.on('SIGINT', () => {
  console.log('\n🛑 Shutting down WebSocket server...');
  server.close(() => {
    console.log('✅ WebSocket server closed');
    process.exit(0);
  });
});

process.on('SIGTERM', () => {
  console.log('\n🛑 Shutting down WebSocket server...');
  server.close(() => {
    console.log('✅ WebSocket server closed');
    process.exit(0);
  });
});

console.log('🎤 AWS Transcribe WebSocket server is running...');
console.log('📡 Connect to: ws://localhost:8080');
console.log('🔧 Press Ctrl+C to stop');
