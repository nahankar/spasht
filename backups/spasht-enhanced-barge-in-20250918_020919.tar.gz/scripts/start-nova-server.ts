#!/usr/bin/env tsx

import 'dotenv/config';

console.log('🚀 [LAUNCH_SCRIPT] Starting FIXED Nova Sonic WebSocket Server...');
console.log(`🚀 [LAUNCH_SCRIPT] Launch ID: ${new Date().toISOString()}`);
console.log('📋 Using proper event sequencing based on reference implementation');

// Import the FIXED implementation
import '../src/lib/nova-websocket-server-v2';

// The nova-websocket-server-fixed.ts file is self-contained and starts the server automatically
// This version implements proper event sequencing to fix voice conversation issues