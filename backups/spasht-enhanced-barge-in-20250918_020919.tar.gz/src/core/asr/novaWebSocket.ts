import type { AsrProvider, AsrState, AsrTranscript } from "./types";

interface ServerMessage {
  type: 'started' | 'promptStartReady' | 'promptReady' | 'partial' | 'final' | 'audio' | 'error' | 'stopped';
  message?: string;
  text?: string;
  audio?: string; // base64 encoded audio response
  confidence?: number;
  error?: string;
}

// Nova Sonic WebSocket ASR provider using bidirectional streaming
export class NovaWebSocketAsr implements AsrProvider {
  private state: AsrState = "idle";
  private onPartialCb: ((t: AsrTranscript) => void) | null = null;
  private onFinalCb: ((t: AsrTranscript) => void) | null = null;
  private onStateCb: ((s: AsrState) => void) | null = null;

  private mediaStream: MediaStream | null = null;
  private audioCtx: AudioContext | null = null;
  private processor: ScriptProcessorNode | null = null;
  private ws: WebSocket | null = null;
  private audioOutputQueue: AudioBuffer[] = [];
  private audioOutputContext: AudioContext | null = null;
  private inactivityTimer: NodeJS.Timeout | null = null;
  private inactivityDelay: number = 1500; // 1.5 seconds of silence

  onPartial(cb: (t: AsrTranscript) => void): void { 
    this.onPartialCb = cb; 
  }
  
  onFinal(cb: (t: AsrTranscript) => void): void { 
    this.onFinalCb = cb; 
  }
  
  onState(cb: (state: AsrState) => void): void { 
    this.onStateCb = cb; 
  }

  private setState(s: AsrState) {
    this.state = s;
    this.onStateCb?.(s);
  }

  async start(): Promise<void> {
    if (this.state === "listening" || this.state === "starting") return;
    
    this.setState("starting");
    
    try {
      // Connect to Nova WebSocket server
      await this.connectWebSocket();
      
      // Set up audio capture
      await this.setupAudioCapture();
      
      // Start the Nova bidirectional stream with all configuration
      this.sendMessage({
        type: 'start',
        language: 'en-US',
        systemPrompt: 'You are a helpful and friendly assistant.'
      });
      
      this.setState("listening");
      console.log('Nova Sonic WebSocket ASR started successfully');
      
      // Re-initialize audio output context for new session
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      this.audioOutputContext = new AudioContextClass();

    } catch (error) {
      console.error('Failed to start Nova Sonic ASR:', error);
      this.setState("error");
      throw error;
    }
  }

  private async connectWebSocket(): Promise<void> {
    return new Promise((resolve, reject) => {
      try {
        this.ws = new WebSocket('ws://localhost:8081');
        
        this.ws.onopen = () => {
          console.log('Connected to Nova Sonic WebSocket server');
          resolve();
        };
        
        this.ws.onmessage = (event) => {
          this.handleServerMessage(event.data);
        };
        
        this.ws.onerror = (error) => {
          console.error('Nova WebSocket error:', error);
          reject(new Error('Failed to connect to Nova WebSocket server'));
        };
        
        this.ws.onclose = () => {
          console.log('Nova WebSocket connection closed');
          if (this.state === "listening") {
            this.setState("error");
          }
        };
        
      } catch (error) {
        reject(error);
      }
    });
  }

  private async setupAudioCapture(): Promise<void> {
    try {
      // Get microphone access
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: { 
          echoCancellation: true, 
          noiseSuppression: true,
          sampleRate: 16000,
          channelCount: 1
        }, 
        video: false 
      });
      
      this.mediaStream = stream;

      // Set up audio processing
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = new AudioContextClass({ sampleRate: 16000 });
      
      // Resume audio context if needed
      if (this.audioCtx.state === 'suspended') {
        await this.audioCtx.resume();
      }
      
      const source = this.audioCtx.createMediaStreamSource(stream);
      const processor = this.audioCtx.createScriptProcessor(4096, 1, 1);
      this.processor = processor;
      
      processor.onaudioprocess = (event) => {
        if (this.state === "listening" && this.ws && this.ws.readyState === WebSocket.OPEN) {
          // Reset inactivity timer
          if (this.inactivityTimer) clearTimeout(this.inactivityTimer);
          this.inactivityTimer = setTimeout(() => {
            console.log('Inactivity detected, stopping audio stream.');
            this.stop();
          }, this.inactivityDelay);

          const inputBuffer = event.inputBuffer;
          const inputData = inputBuffer.getChannelData(0);
          
          // Convert to 16-bit PCM and send to Nova
          const pcmData = this.floatToPCM16(inputData);
          const base64Data = this.arrayBufferToBase64(pcmData.buffer as ArrayBuffer);
          
          this.sendMessage({
            type: 'audio',
            data: base64Data,
            sampleRate: 16000
          });
        }
      };
      
      source.connect(processor);
      processor.connect(this.audioCtx.destination);
      
      // Set up audio output context for Nova responses
      this.audioOutputContext = new AudioContextClass();
      
    } catch (error) {
      console.error('Failed to setup audio capture:', error);
      throw error;
    }
  }

  private handleServerMessage(data: string) {
    try {
      const message: ServerMessage = JSON.parse(data);
      
      switch (message.type) {
        case 'started':
          console.log('Nova Sonic started:', message.message);
          // This is now purely informational.
          break;
          
        case 'promptStartReady':
          console.log('Prompt start ready:', message.message);
          // This is now just an informational message. The client no longer needs to react to it.
          break;
          
        case 'promptReady':
          console.log('🎯 Nova Sonic prompt is ready for audio input!', message.message);
          // Nova Sonic has confirmed the prompt is open and ready, now we can start sending audio.
          this.sendMessage({ type: 'audioStart' });
          break;
          
        case 'partial':
          if (message.text && this.onPartialCb) {
            this.onPartialCb({
              text: message.text,
              confidence: message.confidence || 0.9,
              isFinal: false,
              timestamp: Date.now()
            });
          }
          break;
          
        case 'final':
          if (message.text && this.onFinalCb) {
            this.onFinalCb({
              text: message.text,
              confidence: message.confidence || 1.0,
              isFinal: true,
              timestamp: Date.now()
            });
          }
          break;
          
        case 'audio':
          if (message.audio) {
            this.playAudioResponse(message.audio);
          }
          break;
          
        case 'stopped':
          console.log('Nova Sonic stopped:', message.message);
          this.cleanup();
          this.setState("idle");
          break;

        case 'error':
          console.error('Nova Sonic error:', message.error);
          this.setState("error");
          break;
      }
      
    } catch (error) {
      console.error('Error handling server message:', error);
    }
  }

  private async playAudioResponse(base64Audio: string) {
    try {
      if (!this.audioOutputContext) return;
      
      // Decode base64 audio
      const audioData = this.base64ToArrayBuffer(base64Audio);
      
      // Decode audio buffer
      const audioBuffer = await this.audioOutputContext.decodeAudioData(audioData);
      
      // Play the audio
      const source = this.audioOutputContext.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(this.audioOutputContext.destination);
      source.start();
      
      console.log('Playing Nova Sonic audio response');
      
    } catch (error) {
      console.error('Error playing audio response:', error);
    }
  }

  private sendMessage(message: Record<string, unknown>) {
    try {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify(message));
      } else {
        console.warn('WebSocket not ready for sending message:', message);
      }
    } catch (error) {
      console.error('Error sending WebSocket message:', error);
    }
  }

  private floatToPCM16(float32Array: Float32Array): Int16Array {
    const pcm16 = new Int16Array(float32Array.length);
    for (let i = 0; i < float32Array.length; i++) {
      const sample = Math.max(-1, Math.min(1, float32Array[i]));
      pcm16[i] = sample < 0 ? sample * 0x8000 : sample * 0x7FFF;
    }
    return pcm16;
  }

  private arrayBufferToBase64(buffer: ArrayBuffer): string {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }

  private base64ToArrayBuffer(base64: string): ArrayBuffer {
    const binaryString = window.atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes.buffer;
  }

  async stop(): Promise<void> {
    this.setState("stopping");
    
    // Send stop message to server, but don't clean up locally until server confirms.
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.sendMessage({ type: 'stop' });
    }
  }

  private cleanup() {
    // Close WebSocket
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }

    // Clear inactivity timer
    if (this.inactivityTimer) {
      clearTimeout(this.inactivityTimer);
      this.inactivityTimer = null;
    }
    
    // Stop audio processing
    if (this.processor) {
      this.processor.disconnect();
      this.processor = null;
    }
    
    // Close audio context
    if (this.audioCtx) {
      this.audioCtx.close();
      this.audioCtx = null;
    }
    
    if (this.audioOutputContext) {
      this.audioOutputContext.close();
      this.audioOutputContext = null;
    }
    
    // Stop media stream
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach(track => track.stop());
      this.mediaStream = null;
    }
  }
}
