import type { AsrProvider, AsrState, AsrTranscript } from "./types";

// Protocol version for compatibility
const PROTOCOL_VERSION = "1.0.0";

interface ClientMessage {
  version: string; // Protocol version for compatibility
  type: 'start' | 'audioStart' | 'audio' | 'stop' | 'pause' | 'resume' | 'ping' | 'interrupt_request';
  timestamp: number; // For latency tracking and debugging
  systemPrompt?: string;
  conversationHistory?: Array<{role: 'USER' | 'ASSISTANT', content: string}>;
  data?: string; // For audio data
  sampleRate?: number;
  sequenceId?: number; // For message ordering and deduplication
}

interface ServerMessage {
  version?: string; // Protocol version for compatibility
  type: 'started' | 'promptStartReady' | 'promptReady' | 'partial' | 'final' | 'audio' | 'error' | 'stopped' | 'contentEnd' | 'contentStart' | 'pong' | 'streamComplete' | 'streamReady' | 'paused' | 'resumed' | 'textOutput';
  timestamp?: number;
  message?: string;
  text?: string;
  audio?: string; // base64 encoded audio response
  confidence?: number;
  error?: string;
  stopReason?: string;
  data?: any; // For contentStart data
  role?: 'USER' | 'ASSISTANT' | 'SYSTEM' | 'TOOL';
  content?: string;
  latency?: number; // Round-trip time for pings
}

// FIXED Nova Sonic WebSocket ASR provider with proper sequencing
export class NovaWebSocketAsr implements AsrProvider {
  private state: AsrState = "idle";
  private onPartialCb: ((t: AsrTranscript) => void) | null = null;
  private onFinalCb: ((t: AsrTranscript) => void) | null = null;
  private onStateCb: ((s: AsrState) => void) | null = null;
  private onBargeInCb: (() => void) | null = null;

  private mediaStream: MediaStream | null = null;
  private audioCtx: AudioContext | null = null;
  private processor: ScriptProcessorNode | null = null;
  private ws: WebSocket | null = null;
  private audioOutputQueue: AudioBuffer[] = [];
  private audioOutputContext: AudioContext | null = null;
  private audioWorkletNode: AudioWorkletNode | null = null;
  private inactivityTimer: NodeJS.Timeout | null = null;
  private inactivityDelay: number = 1500;
  
  // Timing tracking for debugging
  private questionStartTime: number = 0;
  private responseStartTime: number = 0;
  private interruptionTime: number = 0;
  
  // Audio start notification tracking
  private hasAudioStartNotified: boolean = false;
  
  // Text buffering for synchronized text/audio presentation
  private bufferedTextResponse: AsrTranscript | null = null;
  private hasAudioStarted: boolean = false;

  // FIXED: Track initialization state
  private isSessionStarted = false;
  private isPromptStartReady = false;
  private isNovaReady = false;
  private isAudioStarted = false;
  
  // Barge-in support - track if we're in conversation mode
  private isInConversation: boolean = false;
  
  // Independent microphone monitoring for precise barge-in timing
  private independentMicStream: MediaStream | null = null;
  private independentAudioContext: AudioContext | null = null;
  private independentAnalyzer: AnalyserNode | null = null;
  private independentMicMonitorActive = false;
  private independentVoiceThreshold = 0.0005; // Very sensitive for precise detection
  private localBargeInEnabled = true; // Enable local barge-in detection
  private localBargeInThreshold = 0.002; // Higher threshold for local barge-in trigger
  private localBargeInCooldown = false; // Prevent multiple rapid triggers
  
  // CRITICAL FIX: Global role tracking like reference app
  private currentRole: 'USER' | 'ASSISTANT' | null = null;
  private shouldContinueListening: boolean = false;
  
  // Reconnection and reliability features
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;
  private reconnectDelay = 1000; // Start with 1 second
  private maxReconnectDelay = 30000; // Max 30 seconds
  private reconnectTimer: NodeJS.Timeout | null = null;
  private heartbeatTimer: NodeJS.Timeout | null = null;
  private heartbeatInterval = 30000; // 30 seconds
  private lastPingTime = 0;
  private sequenceCounter = 0;
  private isReconnecting = false;

  onPartial(cb: (t: AsrTranscript) => void): void { 
    this.onPartialCb = cb; 
  }
  
  onFinal(cb: (t: AsrTranscript) => void): void { 
    this.onFinalCb = cb; 
  }
  
  onState(cb: (state: AsrState) => void): void { 
    this.onStateCb = cb; 
  }

  // Add callback for barge-in events
  onBargeIn(cb: () => void): void {
    this.onBargeInCb = cb;
  }

  private setState(s: AsrState) {
    this.state = s;
    
    // Reset audioStart flag when transitioning to listening state for new conversation turn
    if (s === "listening") {
      this.hasAudioStartNotified = false;
    }
    
    this.onStateCb?.(s);
  }

  async start(conversationHistory?: Array<{role: 'USER' | 'ASSISTANT', content: string}>): Promise<void> {
    if (this.state === "listening" || this.state === "starting") {
      return;
    }
    
    // Start timing for user question
    this.questionStartTime = Date.now();

    // Reset text buffering state for new conversation
    this.hasAudioStarted = false;
    this.bufferedTextResponse = null;
    this.hasAudioStartNotified = false;
    
    this.setState("starting");
    
    try {
      // Connect to Nova WebSocket server
      await this.connectWebSocket();
      
      // Set up audio capture
      await this.setupAudioCapture();
      
      // FIXED: Start proper initialization sequence with conversation history
      await this.initializeSession(conversationHistory);
      
      this.setState("listening");

    } catch (error) {
      console.error('Failed to start Nova Sonic ASR:', error);
      this.setState("error");
      throw error;
    }
  }

  /**
   * Reset the audioStart flag for new conversation turns (used during barge-in)
   */
  resetForNewTurn(): void {
    this.hasAudioStartNotified = false;
  }

  private async connectWebSocket(): Promise<void> {
    return new Promise((resolve, reject) => {
      try {
        this.ws = new WebSocket('ws://localhost:8081');
        
        this.ws.onopen = () => {
          this.reconnectAttempts = 0; // Reset on successful connection
          this.startHeartbeat(); // Start heartbeat system
          resolve();
        };
        
        this.ws.onmessage = (event) => {
          this.handleServerMessage(event.data);
        };
        
        this.ws.onerror = (error) => {
          console.error('Nova WebSocket error:', error);
          reject(new Error('Failed to connect to Nova WebSocket server'));
        };
        
        this.ws.onclose = (event) => {
          console.log('🔌 WebSocket connection closed:', event.code, event.reason);
          this.clearHeartbeatTimer();
          
          // Only attempt reconnection if we were previously connected and not intentionally stopping
          if (this.state !== "idle" && this.state !== "stopping" && !this.isReconnecting) {
            console.log('🔄 Unexpected disconnect - attempting reconnection');
            this.handleReconnection();
          }
          if (this.state === "listening") {
            this.setState("error");
          }
        };
        
      } catch (error) {
        reject(error);
      }
    });
  }

  // FIXED: Simplified initialization - send everything in one message
  private async initializeSession(conversationHistory?: Array<{role: 'USER' | 'ASSISTANT', content: string}>): Promise<void> {
    
    // Build system prompt with conversation history if available
    let systemPrompt = 'You are a helpful and friendly assistant.';
    
    if (conversationHistory && conversationHistory.length > 0) {
      console.log(`📜 Including ${conversationHistory.length} previous messages in context`);
      const contextSummary = conversationHistory
        .map(msg => `${msg.role}: ${msg.content}`)
        .join('\n');
      
      systemPrompt = `You are a helpful and friendly assistant. Here is our previous conversation context:\n\n${contextSummary}\n\nPlease continue our conversation naturally, remembering the context above.`;
    }
    
    // FIXED: Send everything at once with system prompt (including history if available)
    this.sendMessage({ 
      type: 'start',
      systemPrompt: systemPrompt
    });
    
    // Wait for session to be started and ready
    await this.waitForSessionStarted();
    
  }

  private async waitForSessionStarted(): Promise<void> {
    return new Promise((resolve, reject) => {
      if (this.isSessionStarted) {
        resolve();
        return;
      }
      
      const timeout = setTimeout(() => {
        reject(new Error('Timeout waiting for session to start'));
      }, 10000);
      
      const checkInterval = setInterval(() => {
        if (this.isSessionStarted) {
          clearTimeout(timeout);
          clearInterval(checkInterval);
          resolve();
        }
      }, 100);
    });
  }

  private async waitForPromptStartReady(): Promise<void> {
    return new Promise((resolve, reject) => {
      if (this.isPromptStartReady) {
        resolve();
        return;
      }
      
      const timeout = setTimeout(() => {
        reject(new Error('Timeout waiting for prompt start ready'));
      }, 10000);
      
      const checkInterval = setInterval(() => {
        if (this.isPromptStartReady) {
          clearTimeout(timeout);
          clearInterval(checkInterval);
          resolve();
        }
      }, 100);
    });
  }

  private async waitForNovaReady(): Promise<void> {
    return new Promise((resolve, reject) => {
      if (this.isNovaReady) {
        resolve();
        return;
      }
      
      const timeout = setTimeout(() => {
        reject(new Error('Timeout waiting for Nova to be ready'));
      }, 15000);
      
      const checkInterval = setInterval(() => {
        if (this.isNovaReady) {
          clearTimeout(timeout);
          clearInterval(checkInterval);
          resolve();
        }
      }, 100);
    });
  }

  private async setupAudioCapture(): Promise<void> {
    console.log('🎤 setupAudioCapture called');
    try {
      // Get microphone access
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: { 
          echoCancellation: true, 
          noiseSuppression: true,
          sampleRate: 16000,
          channelCount: 1
        }, 
        video: false 
      });
      
      console.log('🎤 Got media stream:', stream.active, 'tracks:', stream.getTracks().length);
      
      this.mediaStream = stream;

      // Set up audio processing
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = new (AudioContextClass as typeof AudioContext)({ sampleRate: 16000 });
      
      // Resume audio context if needed
      if (this.audioCtx.state === 'suspended') {
        await this.audioCtx.resume();
      }
      
      const source = this.audioCtx.createMediaStreamSource(stream);
      const processor = this.audioCtx.createScriptProcessor(4096, 1, 1);
      this.processor = processor;
      
      processor.onaudioprocess = (event) => {
        
        // FIXED: Send audio when Nova is ready and either listening OR in conversation mode (for barge-in)
        const wsReady = this.ws && this.ws.readyState === WebSocket.OPEN;
        const isListeningOrConversation = (this.state === "listening" || (this.isInConversation && this.shouldContinueListening));
        const shouldSendAudio = wsReady && this.isNovaReady && this.isAudioStarted && isListeningOrConversation;
        
            
        if (shouldSendAudio) {
          
          // 🎤 SEND AUDIO START MESSAGE - Notify server that user is speaking
          if (!this.hasAudioStartNotified) {
            console.log(`🎤 Sending audio_start_signal to server`);
            // Send audio_start if we're listening OR in conversation mode (for barge-in)
            if (this.state === "listening" || (this.isInConversation && this.shouldContinueListening)) {
              console.log('✅ CONDITIONS MET: Sending audio_start_signal message');
              this.sendMessage({ type: 'audioStart' });
              this.hasAudioStartNotified = true;
            } else {
              console.log('❌ CONDITIONS NOT MET: Not sending audio_start_signal');
            }
          }
          
          // Reset inactivity timer only if actively listening (not during AI responses)
          if (this.state === "listening") {
            if (this.inactivityTimer) clearTimeout(this.inactivityTimer);
            this.inactivityTimer = setTimeout(() => {
              console.log('Inactivity detected, stopping audio stream.');
              this.stop();
            }, this.inactivityDelay);
          }

          const inputBuffer = event.inputBuffer;
          const inputData = inputBuffer.getChannelData(0);
          
          // Check for voice activity during AI response (simple volume threshold)
          if (this.isInConversation && this.state !== "listening") {
            const volume = this.calculateRMS(inputData);
            // Always log volume during conversation mode for debugging
            if (volume > 0.001) {
              console.log(`🎤 Volume detected during AI response: ${volume.toFixed(4)} (threshold: 0.005)`);
            }
            if (volume > 0.005) { // Lowered threshold for faster barge-in detection
              console.log(`🎤 ⚡ Voice activity detected during AI response (volume: ${volume.toFixed(4)}) - TRIGGERING BARGE-IN`);
              this.triggerBargeIn();
              // Send immediate interrupt signal to Nova
              this.sendMessage({ type: 'interrupt_request' });
            }
          }
          
          // Convert to 16-bit PCM and send to Nova
          const pcmData = this.floatToPCM16(inputData);
          const base64Data = this.arrayBufferToBase64(pcmData.buffer as ArrayBuffer);
          
          this.sendMessage({
            type: 'audio',
            data: base64Data,
            sampleRate: 16000
          });
        }
      };
      
      source.connect(processor);
      processor.connect(this.audioCtx.destination);
      
      // Set up audio output context for Nova responses (24kHz for Nova Sonic)
      this.audioOutputContext = new (AudioContextClass as typeof AudioContext)({
        sampleRate: 24000
      });

      // Initialize AudioWorklet for buffered audio playback
      await this.setupAudioWorklet();
      
    } catch (error) {
      console.error('Failed to setup audio capture:', error);
      throw error;
    }
  }

  private async setupAudioWorklet(): Promise<void> {
    if (!this.audioOutputContext) {
      throw new Error('Audio output context not initialized');
    }

    try {
      // Load the ENHANCED audio worklet processor with better barge-in handling
      await this.audioOutputContext.audioWorklet.addModule('/worklets/audio-player-processor-enhanced.js');
      
      // Create the worklet node
      this.audioWorkletNode = new AudioWorkletNode(this.audioOutputContext, 'audio-player-processor');
      
      // Connect to destination
      this.audioWorkletNode.connect(this.audioOutputContext.destination);
      
      console.log('🎵 AudioWorklet initialized successfully');
    } catch (error) {
      console.error('❌ Failed to setup AudioWorklet:', error);
      throw error;
    }
  }


  private getMessageInfo(message: ServerMessage): string {
    switch (message.type) {
      case 'final':
        return ` - "${message.text?.substring(0, 50) || ''}${message.text && message.text.length > 50 ? '...' : ''}"`;
      case 'audio':
        return ` - ${message.audio?.length || 0} bytes`;
      case 'error':
        return ` - ${message.error || 'unknown error'}`;
      case 'contentEnd':
        return ` - ${message.stopReason || 'END_TURN'}`;
      case 'started':
      case 'promptStartReady':
      case 'promptReady':
      case 'stopped':
      case 'streamComplete':
      case 'streamReady':
      case 'info':
        return ` - ${message.message || ''}`;
      default:
        return '';
    }
  }

  private handleServerMessage(data: string) {
    try {
      const message: ServerMessage = JSON.parse(data);
      // Log only essential message info instead of full raw data
      const messageType = message.type;
      const messageInfo = this.getMessageInfo(message);
      
      switch (message.type) {
        case 'started':
          this.isSessionStarted = true;
          this.isNovaReady = true; // FIXED: Mark as ready immediately after started
          this.isAudioStarted = true; // FIXED: Ready for audio
          break;
          
        case 'promptStartReady':
          this.isPromptStartReady = true;
          break;
          
        case 'promptReady':
          this.isNovaReady = true;
          this.isAudioStarted = true; // Mark audio as started
          break;
          
        case 'contentStart':
          // CRITICAL FIX: Handle contentStart events (like reference app)
          if (message.data) {
            console.log('🏷️ Client received contentStart:', message.data);
            
            // CRITICAL FIX: Set global role like reference app
            if (message.data.type === 'TEXT' && message.data.role) {
              this.currentRole = message.data.role;
              console.log(`🏷️ SET GLOBAL ROLE: ${this.currentRole} for ${message.data.type} content`);
            } else if (message.data.type === 'AUDIO') {
              // Reset audio sync flags when new audio content starts
              this.hasAudioStarted = false;
              console.log(`🎵 Reset audio sync flags for new audio content`);
            }
          }
          break;
          
        case 'partial':
          if (message.text && this.onPartialCb) {
            const partialRole = this.currentRole || (message as any).role || undefined;
            console.log(`🏷️ USING ROLE FOR PARTIAL MESSAGE: ${partialRole} (global: ${this.currentRole}, message: ${(message as any).role})`);
            
            // Add slight delay for partial text when audio is playing for better sync
            if (this.hasAudioStarted) {
              setTimeout(() => {
                if (this.onPartialCb) {
                  this.onPartialCb({
                    text: message.text,
                    confidence: message.confidence || 0.9,
                    isFinal: false,
                    timestamp: Date.now(),
                    role: partialRole // CRITICAL FIX: Include role for partial messages too
                  });
                }
              }, 200); // Increased delay for partial updates to sync with audio
            } else {
              // Show immediately if no audio sync needed
              this.onPartialCb({
                text: message.text,
                confidence: message.confidence || 0.9,
                isFinal: false,
                timestamp: Date.now(),
                role: partialRole // CRITICAL FIX: Include role for partial messages too
              });
            }
          }
          break;
          
        case 'final':
          // 📊 TIMING LOG: Text response received
          const textTime = Date.now();
          const textDelay = textTime - this.questionStartTime;
          // Text response received
          
          // Check for interruption signals in the text content
          if (message.text && (
            message.text.includes('"interrupted" : true') || 
            message.text.includes('interrupted')
          )) {
            console.log('🔇 ⚡ INTERRUPTION SIGNAL DETECTED IN TEXT - CLEARING AUDIO IMMEDIATELY');
            this.triggerBargeIn();
            // Don't process this as a normal response
            break;
          }
          
          if (message.text) {
            const finalRole = this.currentRole || (message as any).role || undefined;
            console.log(`🏷️ USING ROLE FOR FINAL MESSAGE: ${finalRole} (global: ${this.currentRole}, message: ${(message as any).role})`);
            
            const transcript: AsrTranscript = {
              text: message.text,
              confidence: message.confidence || 1.0,
              isFinal: true,
              timestamp: Date.now(),
              role: finalRole // CRITICAL FIX: Use global role like reference app
            };
            
            
            // Buffer text response until audio starts, or show immediately if audio already started
            if (this.hasAudioStarted && this.onFinalCb) {
              this.onFinalCb(transcript);
            } else {
              this.bufferedTextResponse = transcript;
            }
          }
          break;
          
        case 'audio':
          
        // Track first audio response timing
        if (this.responseStartTime === 0) {
          this.responseStartTime = Date.now();
        }
          
          // Mark audio as started and release any buffered text with sync delay
          if (!this.hasAudioStarted) {
            this.hasAudioStarted = true;
            
            // Enter conversation mode for barge-in support
            this.isInConversation = true;
            this.shouldContinueListening = true;
            
            // Start independent microphone monitoring for precise timing
            this.setupIndependentMicMonitoring();
            
            // Release buffered text response with a small delay to sync with audio playback
            if (this.bufferedTextResponse && this.onFinalCb) {
              console.log('📝 Scheduling text release to sync with audio playback...');
              // Add 400ms delay to sync text with audio processing and playback start
              setTimeout(() => {
                if (this.bufferedTextResponse && this.onFinalCb) {
                  console.log('📝 Releasing buffered text response (synced):', this.bufferedTextResponse);
                  this.onFinalCb(this.bufferedTextResponse);
                  this.bufferedTextResponse = null;
                }
              }, 400);
            }
          }
          
          if (message.audio) {
            this.playAudioResponse(message.audio);
          } else {
            console.warn('⚠️ Audio message received but no audio data');
          }
          break;

        case 'textOutput':
          // REFERENCE APP EXACT MATCH: Handle textOutput events like reference app
          // Reduced logging for textOutput events
          if (message.content && this.onFinalCb) {
            const transcript: AsrTranscript = {
              text: message.content,
              confidence: 1.0,
              isFinal: true,
              timestamp: Date.now(),
              role: message.role || this.currentRole || 'ASSISTANT'
            };
            this.onFinalCb(transcript);
          }
          break;

        case 'contentEnd':
          // Reduced logging for contentEnd events
          
          // 📊 TIMING LOG: Content end with stopReason
          if (message.stopReason) {
            // Reduced logging: only log unexpected stop reasons
            if (!['END_TURN', 'PARTIAL_TURN'].includes(message.stopReason)) {
              console.log(`🔚 Content end: ${message.stopReason}`);
            }
            
            // Only trigger barge-in for actual interruptions, not normal completions
            if (message.stopReason === 'INTERRUPTED') {
              this.interruptionTime = Date.now();
              const interruptionDelay = this.interruptionTime - this.questionStartTime;
              const responseToInterruptionDelay = this.interruptionTime - this.responseStartTime;
              
              console.log(`🔇 USER INTERRUPTION DETECTED at ${new Date().toLocaleTimeString()}.${Date.now() % 1000} - triggering barge-in`);
              this.triggerBargeIn();
            } else if (message.stopReason === 'PARTIAL_TURN') {
              // PARTIAL_TURN is normal completion, not an interruption
            } else if (message.stopReason === 'END_TURN') {
              // Normal end of AI response - stay in conversation mode for potential follow-up
            }
          }
          break;

        case 'stopped':
          
          // 📊 TIMING LOG: Conversation ended
          console.log(`📊 [${new Date().toLocaleTimeString()}] 🔚 CONVERSATION ENDED`);
          
          // Reset timing variables for next conversation
          this.questionStartTime = 0;
          this.responseStartTime = 0;
          this.interruptionTime = 0;
          
          // Reset text buffering state
          this.hasAudioStarted = false;
          this.bufferedTextResponse = null;
          
          this.cleanup();
          this.setState("idle");
          break;

        case 'error':
          console.error('Nova Sonic error:', message.error);
          
          // Check if this is a recoverable AWS stream error
          if (message.error?.includes('response stream') || message.error?.includes('model stream')) {
            console.log('🔄 Detected AWS stream error - attempting recovery...');
            // Don't set error state, allow conversation to continue
            // The audio that was playing will finish, then user can continue
            this.isInConversation = false;
            this.hasAudioStarted = false;
            this.bufferedTextResponse = null;
          } else {
            this.setState("error");
          }
          break;
          
        case 'streamComplete':
          console.log('🎯 Stream completed normally:', message.message);
          
          // FOR INTERVIEWS: Reset conversation flags but keep session alive
          this.isInConversation = false;
          this.bufferedTextResponse = null;
          this.currentRole = null;
          
          // Reset Nova session flags to allow proper restart from server
          this.isNovaReady = false;
          this.isAudioStarted = false;
          // Keep this.isSessionStarted = true to maintain WebSocket connection
          
          // Set state to listening - ready for next question immediately
          this.setState("listening");
          
          break;
          
        case 'paused':
          this.setState("paused");
          break;
          
        case 'resumed':
          this.setState("listening");
          break;
          
        case 'streamReady':
          // Ensure we're in listening state when stream is ready
          this.setState("listening");
          
          // Re-activate audio input after stream restart
          setTimeout(() => {
            if (this.ws && this.ws.readyState === WebSocket.OPEN && this.isSessionStarted) {
              this.sendMessage({ type: 'audioStart' });
            }
          }, 100); // Small delay to ensure server is ready
          break;
          
        case 'info':
          // Don't change state for info messages
          break;
          
        case 'pong':
          // Handle heartbeat pong response
          this.handlePong(message);
          break;
      }
      
    } catch (error) {
      console.error('Error handling server message:', error);
    }
  }

  private async playAudioResponse(base64Audio: string) {
    try {
      if (!this.audioWorkletNode) {
        console.error('❌ No audioWorkletNode available for playback');
        return;
      }
      
      // Convert base64 to Float32Array like the reference implementation
      const audioData = this.base64ToFloat32Array(base64Audio);
      
      // Send audio data to the worklet for buffered playback
      this.audioWorkletNode.port.postMessage({
        type: "audio",
        audioData: audioData,
      });
      
      
    } catch (error) {
      console.error('❌ Error playing audio response:', error);
    }
  }

  private sendMessage(messageData: Partial<ClientMessage>) {
    try {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        // Add protocol version and timestamp to all messages
        const message: ClientMessage = {
          version: PROTOCOL_VERSION,
          timestamp: Date.now(),
          sequenceId: ++this.sequenceCounter,
          ...messageData,
          type: messageData.type as ClientMessage['type'] // Type assertion for required field
        };
        
        this.ws.send(JSON.stringify(message));
      } else {
        console.warn('⚠️ WebSocket not ready, cannot send message:', messageData.type);
        // If not connected and not already reconnecting, try to reconnect
        if (!this.isReconnecting && this.state !== "idle") {
          this.handleReconnection();
        }
      }
    } catch (error) {
      console.error('❌ Error sending message:', error);
    }
  }

  private sendPlainTextMessage(message: string) {
    try {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        console.log(`🚨 CLIENT: Sending plain text message to server: ${message}`);
        this.ws.send(message);
        console.log(`✅ CLIENT: Plain text message sent successfully: ${message}`);
      } else {
        console.warn(`WebSocket not ready for sending plain text message (state: ${this.ws?.readyState}):`, message);
      }
    } catch (error) {
      console.error('Error sending plain text WebSocket message:', error);
    }
  }

  private floatToPCM16(float32Array: Float32Array): Int16Array {
    const pcm16 = new Int16Array(float32Array.length);
    for (let i = 0; i < float32Array.length; i++) {
      const sample = Math.max(-1, Math.min(1, float32Array[i]));
      pcm16[i] = sample < 0 ? sample * 0x8000 : sample * 0x7FFF;
    }
    return pcm16;
  }

  private calculateRMS(float32Array: Float32Array): number {
    let sum = 0;
    for (let i = 0; i < float32Array.length; i++) {
      sum += float32Array[i] * float32Array[i];
    }
    return Math.sqrt(sum / float32Array.length);
  }

  private arrayBufferToBase64(buffer: ArrayBuffer): string {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }

  private base64ToArrayBuffer(base64: string): ArrayBuffer {
    const binaryString = window.atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes.buffer;
  }

  // FIXED: Convert base64 to Float32Array like the reference implementation
  private base64ToFloat32Array(base64String: string): Float32Array {
    try {
      const binaryString = window.atob(base64String);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      const int16Array = new Int16Array(bytes.buffer);
      const float32Array = new Float32Array(int16Array.length);
      for (let i = 0; i < int16Array.length; i++) {
        float32Array[i] = int16Array[i] / 32768.0; // Convert to -1.0 to 1.0 range
      }

      return float32Array;
    } catch (error) {
      console.error('Error in base64ToFloat32Array:', error);
      throw error;
    }
  }

  // Pause the interview session
  pause() {
    console.log('Pausing Nova Sonic interview session');
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.sendMessage({ type: 'pause' });
    }
  }

  // Resume the interview session  
  async resume(conversationHistory?: Array<{role: 'USER' | 'ASSISTANT', content: string}>) {
    console.log('Resuming Nova Sonic interview session with conversation history');
    
    // If WebSocket is closed (which happens after pause), restart the entire session
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      console.log('🔄 WebSocket closed after pause, restarting entire Nova Sonic session...');
      
      // Reset all session flags for clean restart
      this.isSessionStarted = false;
      this.isNovaReady = false;
      this.isAudioStarted = false;
      this.conversationState = 'idle';
      
      // Start fresh Nova Sonic session with conversation context
      await this.start(conversationHistory);
      console.log('✅ Nova Sonic session restarted successfully after resume with context');
    } else {
      // If WebSocket is still open, just send resume message with context
      this.sendMessage({ 
        type: 'resume',
        conversationHistory: conversationHistory 
      });
    }
  }

  async stop(): Promise<void> {
    this.setState("stopping");
    
    // Clear all timers
    this.clearReconnectionTimer();
    this.clearHeartbeatTimer();
    
    // Stop independent microphone monitoring
    this.stopIndependentMicMonitoring();
    
    // Stop any running TTS immediately
    if ('speechSynthesis' in window) {
      speechSynthesis.cancel();
      console.log('🔇 Stopped all TTS speech');
    }
    
    // Send stop message to server
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.sendMessage({ type: 'stop' });
    }
    
    // Reset reconnection state
    this.isReconnecting = false;
    this.reconnectAttempts = 0;
  }

  // NEW: Allow external control of conversation mode for barge-in
  enableConversationMode(): void {
    console.log('🔄 Conversation mode enabled externally');
    this.isInConversation = true;
    this.shouldContinueListening = true;
  }

  disableConversationMode(): void {
    console.log('🔄 Conversation mode disabled externally');
    this.isInConversation = false;
    this.shouldContinueListening = false;
  }

  isInConversationMode(): boolean {
    return this.isInConversation;
  }

  private async setupIndependentMicMonitoring(): Promise<void> {
    try {
      console.log('🎤 📊 Setting up independent microphone monitoring for precise barge-in timing...');
      
      // Get independent microphone access
      this.independentMicStream = await navigator.mediaDevices.getUserMedia({ 
        audio: { 
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true 
        } 
      });
      
      // Create independent audio context
      this.independentAudioContext = new AudioContext();
      const source = this.independentAudioContext.createMediaStreamSource(this.independentMicStream);
      
      // Create analyzer for voice detection
      this.independentAnalyzer = this.independentAudioContext.createAnalyser();
      this.independentAnalyzer.fftSize = 256;
      source.connect(this.independentAnalyzer);
      
      this.independentMicMonitorActive = true;
      this.startIndependentVoiceMonitoring();
      
      console.log('✅ Independent microphone monitoring active');
    } catch (error) {
      console.error('❌ Failed to setup independent microphone monitoring:', error);
    }
  }
  
  private startIndependentVoiceMonitoring(): void {
    if (!this.independentAnalyzer || !this.independentMicMonitorActive) return;
    
    const bufferLength = this.independentAnalyzer.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    
    const checkVoiceActivity = () => {
      if (!this.independentMicMonitorActive || !this.independentAnalyzer) return;
      
      this.independentAnalyzer.getByteFrequencyData(dataArray);
      
      // Calculate RMS volume
      let sum = 0;
      for (let i = 0; i < bufferLength; i++) {
        const amplitude = dataArray[i] / 255.0;
        sum += amplitude * amplitude;
      }
      const rms = Math.sqrt(sum / bufferLength);
      
      // Always log volume levels for debugging (only during AI response)
      if (this.isInConversation && this.state !== "listening") {
        if (rms > 0.0001) { // Log any detectable voice activity
          const timestamp = new Date().toLocaleTimeString() + '.' + (Date.now() % 1000);
          
          if (rms > this.independentVoiceThreshold) {
            console.log(`🎤 📊 INDEPENDENT MIC: ⚡ REAL USER SPEECH DETECTED at ${timestamp} (volume: ${rms.toFixed(4)}) - ACTUAL BARGE-IN MOMENT!`);
            
            // LOCAL BARGE-IN: Trigger immediate audio clearing without waiting for Nova Sonic
            if (this.localBargeInEnabled && rms > this.localBargeInThreshold && !this.localBargeInCooldown) {
              console.log(`🔇 ⚡ LOCAL BARGE-IN TRIGGERED at ${timestamp} (volume: ${rms.toFixed(4)}) - IMMEDIATE AUDIO STOP!`);
              this.triggerLocalBargeIn();
            }
          } else {
            console.log(`🎤 📊 Independent mic: voice activity ${timestamp} (volume: ${rms.toFixed(4)}) - below threshold`);
          }
        }
      }
      
      requestAnimationFrame(checkVoiceActivity);
    };
    
    checkVoiceActivity();
  }
  
  private stopIndependentMicMonitoring(): void {
    console.log('🎤 📊 Stopping independent microphone monitoring...');
    
    this.independentMicMonitorActive = false;
    
    if (this.independentMicStream) {
      this.independentMicStream.getTracks().forEach(track => track.stop());
      this.independentMicStream = null;
    }
    
    if (this.independentAudioContext) {
      this.independentAudioContext.close();
      this.independentAudioContext = null;
    }
    
    this.independentAnalyzer = null;
    console.log('✅ Independent microphone monitoring stopped');
  }

  private cleanup() {
    // Stop independent microphone monitoring
    this.stopIndependentMicMonitoring();
    
    // Reset state flags
    this.isSessionStarted = false;
    this.isPromptStartReady = false;
    this.isNovaReady = false;
    this.isAudioStarted = false;
    
    // Reset conversation state
    this.isInConversation = false;
    this.shouldContinueListening = false;

    // Close WebSocket
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }

    // Clear inactivity timer
    if (this.inactivityTimer) {
      clearTimeout(this.inactivityTimer);
      this.inactivityTimer = null;
    }
    
    // Stop audio processing
    if (this.processor) {
      this.processor.disconnect();
      this.processor = null;
    }
    
    // Close audio context
    if (this.audioCtx) {
      this.audioCtx.close();
      this.audioCtx = null;
    }
    
    if (this.audioWorkletNode) {
      this.audioWorkletNode.disconnect();
      this.audioWorkletNode = null;
    }
    
    if (this.audioOutputContext) {
      this.audioOutputContext.close();
      this.audioOutputContext = null;
    }
    
    // Stop media stream
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach(track => track.stop());
      this.mediaStream = null;
    }
  }

  // Reconnection logic with exponential backoff
  private handleReconnection(): void {
    if (this.isReconnecting || this.state === "idle") {
      return;
    }
    
    this.isReconnecting = true;
    this.clearHeartbeatTimer();
    
    const delay = Math.min(this.reconnectDelay * Math.pow(2, this.reconnectAttempts), this.maxReconnectDelay);
    console.log(`🔄 Attempting reconnection ${this.reconnectAttempts + 1}/${this.maxReconnectAttempts} in ${delay}ms`);
    
    this.reconnectTimer = setTimeout(async () => {
      if (this.reconnectAttempts >= this.maxReconnectAttempts) {
        console.error('❌ Max reconnection attempts reached, giving up');
        this.setState("idle");
        this.isReconnecting = false;
        return;
      }
      
      this.reconnectAttempts++;
      
      try {
        // Close existing connection
        if (this.ws) {
          this.ws.close();
          this.ws = null;
        }
        
        // Reset session flags for clean reconnection
        this.isSessionStarted = false;
        this.isNovaReady = false;
        this.isAudioStarted = false;
        
        // Attempt to reconnect
        await this.connectWebSocket();
        await this.initializeSession();
        
        console.log('✅ Reconnection successful');
        this.reconnectAttempts = 0;
        this.isReconnecting = false;
        this.startHeartbeat();
        
      } catch (error) {
        console.error('❌ Reconnection failed:', error);
        this.isReconnecting = false;
        this.handleReconnection(); // Try again
      }
    }, delay);
  }
  
  private clearReconnectionTimer(): void {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
  }
  
  // Heartbeat system
  private startHeartbeat(): void {
    this.clearHeartbeatTimer();
    this.heartbeatTimer = setInterval(() => {
      this.sendPing();
    }, this.heartbeatInterval);
  }
  
  private clearHeartbeatTimer(): void {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = null;
    }
  }
  
  private sendPing(): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.lastPingTime = Date.now();
      this.sendMessage({ type: 'ping' });
    } else {
      console.warn('⚠️ Cannot send ping - WebSocket not ready');
      this.handleReconnection();
    }
  }
  
  private handlePong(message: ServerMessage): void {
    if (this.lastPingTime > 0) {
      const latency = Date.now() - this.lastPingTime;
      // Reduced logging: only log high latency pings
      if (latency > 1000) {
        console.log(`🏓 High latency detected: ${latency}ms`);
      }
      this.lastPingTime = 0;
    }
  }

  private triggerBargeIn(): void {
    const bargeInTime = Date.now();
    console.log(`🔇 BARGE-IN TRIGGERED at ${new Date().toLocaleTimeString()}.${Date.now() % 1000}`);
    
    // Stop any running TTS immediately
    if ('speechSynthesis' in window) {
      speechSynthesis.cancel();
      console.log('🔇 Stopped TTS during barge-in');
    }
    
    if (this.audioWorkletNode) {
      // Clear the audio buffer to stop current playback immediately
      this.audioWorkletNode.port.postMessage({
        type: "barge-in",
      });
      // Send backup clear message for extra safety
      this.audioWorkletNode.port.postMessage({
        type: "clear",
      });
      console.log('🔇 ✅ Barge-in triggered - audio buffer cleared immediately');
    } else {
      console.warn('⚠️ Cannot trigger barge-in - no audio worklet node available');
    }

    // Clear any queued audio buffers
    this.audioOutputQueue = [];
    console.log('🔇 Cleared audio output queue');
    
    // CRITICAL: Notify the main application about the barge-in event
    // This will trigger the state transition from 'ai_responding' to 'user_speaking'
    if (this.onBargeInCb) {
      this.onBargeInCb();
      console.log('🔔 Barge-in callback triggered - notifying main app');
    }
    
    const bargeInCompleteTime = Date.now();
    const bargeInDuration = bargeInCompleteTime - bargeInTime;
    console.log(`📊 Barge-in completed in: ${bargeInDuration}ms`);
  }

  private triggerLocalBargeIn(): void {
    console.log(`🔇 ⚡ LOCAL BARGE-IN: Immediate audio stop without waiting for Nova Sonic`);
    
    // Set cooldown to prevent rapid triggering
    this.localBargeInCooldown = true;
    setTimeout(() => {
      this.localBargeInCooldown = false;
      console.log(`🔇 Local barge-in cooldown reset`);
    }, 1000);
    
    // Immediately clear audio buffer
    if (this.audioWorkletNode) {
      this.audioWorkletNode.port.postMessage({ type: "barge-in" });
      this.audioWorkletNode.port.postMessage({ type: "clear" });
      console.log('🔇 ⚡ LOCAL: Audio buffer cleared immediately');
    }
    
    // Stop TTS
    if ('speechSynthesis' in window) {
      speechSynthesis.cancel();
      console.log('🔇 ⚡ LOCAL: TTS stopped immediately');
    }
    
    // Clear audio queue
    this.audioOutputQueue = [];
    console.log('🔇 ⚡ LOCAL: Audio queue cleared');
    
    // Notify app immediately (don't wait for Nova Sonic's signal)
    if (this.onBargeInCb) {
      this.onBargeInCb();
      console.log('🔇 ⚡ LOCAL: Barge-in callback triggered immediately');
    }
  }
}
