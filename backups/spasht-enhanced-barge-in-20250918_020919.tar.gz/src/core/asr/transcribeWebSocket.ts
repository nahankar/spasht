import type { AsrProvider, AsrTranscript, AsrState } from "./types";

interface ServerMessage {
  type: 'started' | 'stopped' | 'partial' | 'final' | 'error';
  text?: string;
  confidence?: number;
  message?: string;
  error?: string;
}

export class TranscribeWebSocketAsr implements AsrProvider {
  private ws: WebSocket | null = null;
  private isStarted = false;
  private audioContext: AudioContext | null = null;
  private processor: ScriptProcessorNode | null = null;
  private source: MediaStreamAudioSourceNode | null = null;

  private onPartialCb?: (t: AsrTranscript) => void;
  private onFinalCb?: (t: AsrTranscript) => void;
  private onStateCb?: (state: AsrState) => void;

  onPartial(cb: (t: AsrTranscript) => void): void {
    this.onPartialCb = cb;
  }

  onFinal(cb: (t: AsrTranscript) => void): void {
    this.onFinalCb = cb;
  }

  onState(cb: (state: AsrState) => void): void {
    this.onStateCb = cb;
  }

  async start(): Promise<void> {
    if (this.isStarted) return;

    try {
      // Connect to WebSocket server
      await this.connectWebSocket();
      
      // Setup audio capture
      await this.setupAudioCapture();

      // Start transcription
      this.sendMessage({
        type: 'start',
        sampleRate: 16000,
        language: 'en-US'
      });

      this.isStarted = true;
      this.onStateCb?.("listening");
      
    } catch (error) {
      console.error("TranscribeWebSocket start failed:", error);
      throw new Error(`AWS Transcribe WebSocket failed: ${(error as Error)?.message || 'Unknown error'}`);
    }
  }

  async stop(): Promise<void> {
    if (!this.isStarted) return;

    try {
      // Stop transcription
      if (this.ws) {
        this.sendMessage({ type: 'stop' });
      }

      // Cleanup audio
      this.cleanupAudio();

      // Close WebSocket
      if (this.ws) {
        this.ws.close();
        this.ws = null;
      }

      this.isStarted = false;
      this.onStateCb?.("idle");
      
    } catch (error) {
      console.warn("TranscribeWebSocket stop error:", error);
    }
  }

  private async connectWebSocket(): Promise<void> {
    return new Promise((resolve, reject) => {
      try {
        this.ws = new WebSocket('ws://localhost:8080');

        this.ws.onopen = () => {
          console.log('WebSocket connected to AWS Transcribe server');
          resolve();
        };

        this.ws.onmessage = (event) => {
          this.handleServerMessage(event.data);
        };

        this.ws.onerror = (error) => {
          console.error('WebSocket error:', error);
          reject(new Error('WebSocket connection failed'));
        };

        this.ws.onclose = () => {
          console.log('WebSocket connection closed');
          if (this.isStarted) {
            this.onStateCb?.("error");
          }
        };

      } catch (error) {
        reject(error);
      }
    });
  }

  private handleServerMessage(data: string) {
    try {
      const message: ServerMessage = JSON.parse(data);

      switch (message.type) {
        case 'started':
          console.log('AWS Transcribe started:', message.message);
          break;
        case 'partial':
          if (message.text && this.onPartialCb) {
            this.onPartialCb({
              text: message.text,
              confidence: message.confidence || 1.0,
              isFinal: false,
              timestamp: Date.now()
            });
          }
          break;
        case 'final':
          if (message.text && this.onFinalCb) {
            this.onFinalCb({
              text: message.text,
              confidence: message.confidence || 1.0,
              isFinal: true,
              timestamp: Date.now()
            });
          }
          break;
        case 'error':
          console.error('AWS Transcribe error:', message.error);
          throw new Error(message.error);
        case 'stopped':
          console.log('AWS Transcribe stopped:', message.message);
          break;
      }
    } catch (error) {
      console.error('Error handling server message:', error);
    }
  }

  private async setupAudioCapture(): Promise<void> {
    try {
      // Get microphone access
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          sampleRate: 16000,
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true,
        }
      });

      // Setup audio context
      this.audioContext = new AudioContext({ sampleRate: 16000 });
      this.source = this.audioContext.createMediaStreamSource(stream);

      // Use ScriptProcessorNode for audio processing
      this.processor = this.audioContext.createScriptProcessor(4096, 1, 1);
      
      this.processor.onaudioprocess = (event) => {
        if (!this.isStarted) return;

        const inputData = event.inputBuffer.getChannelData(0);
        
        // Convert to 16-bit PCM
        const pcmData = new Int16Array(inputData.length);
        for (let i = 0; i < inputData.length; i++) {
          pcmData[i] = Math.max(-32768, Math.min(32767, inputData[i] * 32767));
        }

        // Send audio data via WebSocket
        const base64Data = this.arrayBufferToBase64(pcmData.buffer);
        this.sendMessage({
          type: 'audio',
          data: base64Data
        });
      };

      // Connect audio nodes
      this.source.connect(this.processor);
      this.processor.connect(this.audioContext.destination);

    } catch (error) {
      throw new Error(`Audio setup failed: ${(error as Error)?.message}`);
    }
  }

  private cleanupAudio() {
    if (this.processor) {
      this.processor.disconnect();
      this.processor = null;
    }
    if (this.source) {
      this.source.disconnect();
      this.source = null;
    }
    if (this.audioContext) {
      this.audioContext.close().catch(console.warn);
      this.audioContext = null;
    }
  }

  private sendMessage(message: Record<string, unknown>) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message));
    }
  }

  private arrayBufferToBase64(buffer: ArrayBuffer): string {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }
}
