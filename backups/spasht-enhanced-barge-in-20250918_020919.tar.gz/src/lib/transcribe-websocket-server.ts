import { WebSocketServer, WebSocket } from 'ws';
import {
  TranscribeStreamingClient,
  StartStreamTranscriptionCommand,
  LanguageCode,
  MediaEncoding,
} from "@aws-sdk/client-transcribe-streaming";

interface AudioMessage {
  type: 'audio';
  data: string; // base64 encoded audio chunk
}

interface StartMessage {
  type: 'start';
  sampleRate?: number;
  language?: string;
}

interface StopMessage {
  type: 'stop';
}

type ClientMessage = AudioMessage | StartMessage | StopMessage;

class TranscribeWebSocketHandler {
  private client: TranscribeStreamingClient;
  private transcribeCommand: StartStreamTranscriptionCommand | null = null;
  private audioStream: ReadableStream<Uint8Array> | null = null;
  private writer: WritableStreamDefaultWriter<Uint8Array> | null = null;
  private ws: WebSocket;

  constructor(ws: WebSocket) {
    this.ws = ws;
    
    // Debug AWS credentials
    console.log('AWS Credentials Check:');
    console.log('- AWS_REGION:', process.env.AWS_REGION || 'NOT SET');
    console.log('- AWS_ACCESS_KEY_ID exists:', !!process.env.AWS_ACCESS_KEY_ID);
    console.log('- AWS_ACCESS_KEY_ID length:', process.env.AWS_ACCESS_KEY_ID?.length || 0);
    console.log('- AWS_SECRET_ACCESS_KEY exists:', !!process.env.AWS_SECRET_ACCESS_KEY);
    console.log('- AWS_SECRET_ACCESS_KEY length:', process.env.AWS_SECRET_ACCESS_KEY?.length || 0);
    
    if (!process.env.AWS_ACCESS_KEY_ID || !process.env.AWS_SECRET_ACCESS_KEY) {
      throw new Error('AWS credentials not found in environment variables');
    }
    
    this.client = new TranscribeStreamingClient({
      region: process.env.AWS_REGION || "us-east-1",
      credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
      },
    });
  }

  async handleMessage(message: string) {
    try {
      const data: ClientMessage = JSON.parse(message);

      switch (data.type) {
        case 'start':
          await this.startTranscription(data.sampleRate || 16000, data.language || 'en-US');
          break;
        case 'audio':
          await this.processAudioChunk(data.data);
          break;
        case 'stop':
          await this.stopTranscription();
          break;
      }
    } catch (error) {
      console.error('Error handling WebSocket message:', error);
      this.sendError((error as Error)?.message || 'Unknown error');
    }
  }

  private async startTranscription(sampleRate: number, language: string) {
    try {
      console.log('Starting AWS Transcribe streaming...');

      // Create audio stream
      const { readable, writable } = new TransformStream<Uint8Array>();
      this.audioStream = readable;
      this.writer = writable.getWriter();

      // Create transcription command
      this.transcribeCommand = new StartStreamTranscriptionCommand({
        LanguageCode: language as LanguageCode,
        MediaEncoding: MediaEncoding.PCM,
        MediaSampleRateHertz: sampleRate,
        AudioStream: this.audioStreamGenerator(),
      });

      // Start transcription
      const response = await this.client.send(this.transcribeCommand);

      // Process results
      if (response.TranscriptResultStream) {
        this.processTranscriptStream(response.TranscriptResultStream);
      }

      this.sendMessage({ type: 'started', message: 'Transcription started' });

    } catch (error) {
      console.error('Failed to start transcription:', error);
      this.sendError(`Failed to start transcription: ${(error as Error)?.message}`);
    }
  }

  private async processAudioChunk(base64Data: string) {
    if (!this.writer) {
      console.warn('Audio chunk received but no writer available');
      return;
    }

    try {
      // Decode base64 audio data
      const audioData = Buffer.from(base64Data, 'base64');
      const uint8Array = new Uint8Array(audioData);

      // Write to stream
      await this.writer.write(uint8Array);
    } catch (error) {
      console.error('Error processing audio chunk:', error);
    }
  }

  private async stopTranscription() {
    try {
      if (this.writer) {
        await this.writer.close();
        this.writer = null;
      }
      this.audioStream = null;
      this.transcribeCommand = null;

      this.sendMessage({ type: 'stopped', message: 'Transcription stopped' });
    } catch (error) {
      console.error('Error stopping transcription:', error);
    }
  }

  private async* audioStreamGenerator(): AsyncGenerator<{ AudioEvent: { AudioChunk: Uint8Array } }> {
    if (!this.audioStream) return;

    const reader = this.audioStream.getReader();
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        yield { AudioEvent: { AudioChunk: value } };
      }
    } finally {
      reader.releaseLock();
    }
  }

  private async processTranscriptStream(stream: AsyncIterable<unknown>) {
    try {
      for await (const event of stream) {
        const typedEvent = event as { TranscriptEvent?: { Transcript?: { Results?: Array<{ Alternatives?: Array<{ Transcript?: string; Items?: Array<{ Confidence?: number; Type?: string }> }>; IsPartial?: boolean }> } } };
        if (typedEvent.TranscriptEvent?.Transcript?.Results) {
          for (const result of typedEvent.TranscriptEvent.Transcript.Results) {
            if (result.Alternatives && result.Alternatives[0]) {
              const transcript = result.Alternatives[0].Transcript || "";
              const confidence = result.Alternatives[0].Items?.[0]?.Confidence || 1.0;
              
              this.sendMessage({
                type: result.IsPartial ? 'partial' : 'final',
                text: transcript,
                confidence: confidence,
              });
            }
          }
        }
      }
    } catch (error) {
      console.error('Error processing transcript stream:', error);
      this.sendError(`Transcript processing error: ${(error as Error)?.message}`);
    }
  }

  private sendMessage(message: Record<string, unknown>) {
    if (this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message));
    }
  }

  private sendError(error: string) {
    this.sendMessage({ type: 'error', error });
  }

  cleanup() {
    this.stopTranscription().catch(console.error);
  }
}

export function createTranscribeWebSocketServer(port: number = 8080) {
  const wss = new WebSocketServer({ port });

  console.log(`🎤 AWS Transcribe WebSocket server started on ws://localhost:${port}`);

  wss.on('connection', (ws) => {
    console.log('New WebSocket connection established');
    const handler = new TranscribeWebSocketHandler(ws);

    ws.on('message', (data) => {
      handler.handleMessage(data.toString());
    });

    ws.on('close', () => {
      console.log('WebSocket connection closed');
      handler.cleanup();
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      handler.cleanup();
    });
  });

  return wss;
}
