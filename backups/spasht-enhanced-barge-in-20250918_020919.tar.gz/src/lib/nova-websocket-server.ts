import { WebSocketServer, WebSocket } from 'ws';
import { 
  BedrockRuntimeClient,
  InvokeModelWithBidirectionalStreamCommand 
} from '@aws-sdk/client-bedrock-runtime';
import { fromNodeProviderChain } from '@aws-sdk/credential-providers';
import { v4 as uuidv4 } from 'uuid';
import { Subject } from 'rxjs';

/**
 * Nova Sonic WebSocket Server - Proper AWS SDK Implementation
 * Based on the working sample-nova-sonic-mcp-main reference
 */

interface ClientMessage {
  type: 'start' | 'audioStart' | 'audio' | 'stop';
  language?: string;
  data?: string;
  sampleRate?: number;
  systemPrompt?: string;
}

interface ServerMessage {
  type: 'started' | 'promptStartReady' | 'promptReady' | 'partial' | 'final' | 'audio' | 'error' | 'stopped';
  message?: string;
  text?: string;
  audio?: string; // base64 encoded audio
  confidence?: number;
  error?: string;
}

interface SessionData {
  queue: Record<string, unknown>[];
  queueSignal: Subject<void>;
  closeSignal: Subject<void>;
  responseSubject: Subject<Record<string, unknown>>;
  promptName: string;
  contentName: string; 
  isActive: boolean;
  isPromptStartSent: boolean;
  isContentStartSent: boolean;
}

class NovaSDKHandler {
  private ws: WebSocket;
  private sessionId: string;
  private bedrockClient: BedrockRuntimeClient;
  private session: SessionData | null = null;
  private region: string;
  private textEncoder = new TextEncoder();
  private textDecoder = new TextDecoder('utf-8');

  constructor(ws: WebSocket) {
    this.ws = ws;
    this.sessionId = this.generateSessionId();
    this.region = process.env.AWS_REGION || 'us-east-1';
    
    // Initialize AWS Bedrock client
    this.bedrockClient = new BedrockRuntimeClient({
      region: this.region,
      credentials: fromNodeProviderChain(),
    });

    // Initialize session
    this.session = {
      queue: [],
      queueSignal: new Subject<void>(),
      closeSignal: new Subject<void>(),
      responseSubject: new Subject<Record<string, unknown>>(),
      promptName: uuidv4(),
      contentName: uuidv4(),
      isActive: true,
      isPromptStartSent: false,
      isContentStartSent: false, // Initialize here
    };

    console.log(`Nova SDK Handler - Session: ${this.sessionId}`);
    console.log(`- AWS_REGION: ${this.region}`);
    console.log(`- AWS_ACCESS_KEY_ID exists: ${!!process.env.AWS_ACCESS_KEY_ID}`);
    console.log(`- AWS_SECRET_ACCESS_KEY exists: ${!!process.env.AWS_SECRET_ACCESS_KEY}`);

    if (!process.env.AWS_ACCESS_KEY_ID || !process.env.AWS_SECRET_ACCESS_KEY) {
      throw new Error('AWS credentials not found in environment variables');
    }
  }

  private generateSessionId(): string {
    return `nova-session-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  private sendMessage(message: ServerMessage) {
    if (this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message));
    }
  }

  async handleMessage(message: string) {
    try {
      const data: ClientMessage = JSON.parse(message.toString());

      switch (data.type) {
        case 'start':
          await this.startBidirectionalStream(data.language || 'en-US', data.systemPrompt);
          break;
        case 'audioStart':
          // This is now redundant as contentStart is sent automatically.
          // We can leave this here, it does no harm.
          break;
        case 'audio':
          await this.processAudioChunk(data.data, data.sampleRate);
          break;
        case 'stop':
          await this.stopBidirectionalStream();
          break;
        default:
          console.warn('Unknown message type:', data.type);
      }
    } catch (error) {
      console.error('Error handling message:', error);
      this.sendMessage({
        type: 'error',
        error: `Message handling error: ${error instanceof Error ? error.message : 'Unknown error'}`
      });
    }
  }

  async startBidirectionalStream(_language: string = 'en-US', systemPrompt?: string) {
    if (!this.session) {
      console.error('Session not initialized');
      return;
    }

    try {
      console.log(`Starting Nova Sonic bidirectional stream for session ${this.sessionId}...`);
      
      // The full sequence must be sent upfront to avoid timeouts
      this.setupSessionStartEvent();
      await this.setupPromptStart();
      this.setupSystemPrompt(systemPrompt);
      
      // CRITICAL FIX: Send our audio contentStart event immediately after setup.
      this.setupContentStartEvent();

      const asyncIterable = this.createSessionAsyncIterable();
      
      const command = new InvokeModelWithBidirectionalStreamCommand({
        modelId: 'amazon.nova-sonic-v1:0',
        body: asyncIterable,
      });

      const response = await this.bedrockClient.send(command);

      console.log(`Session ${this.sessionId} stream established successfully`);
      this.sendMessage({ type: 'started', message: 'Nova Sonic bidirectional stream started' });

      await this.processResponseStream(response);
    } catch (error: unknown) {
      console.error(`Failed to start Nova Sonic bidirectional stream: ${error}`);
      this.sendMessage({
        type: 'error',
        error: `Failed to start stream: ${error instanceof Error ? error.message : 'Unknown error'}`
      });
    }
  }

  private setupSessionStartEvent() {
    if (!this.session) return;

    const sessionStartEvent = {
      event: {
        sessionStart: {
          inferenceConfiguration: {
            maxTokens: 2000,
            temperature: 0.7,
            topP: 0.9
          }
        }
      }
    };

    this.addEventToQueue(sessionStartEvent);
  }

  async setupPromptStart() {
    if (!this.session) {
      console.error('Session not initialized');
      return;
    }

    if (this.session.isPromptStartSent) {
      console.log('Prompt start already sent');
      return;
    }

    const promptStartEvent = {
      event: {
        promptStart: {
          promptName: this.session.promptName,
          textOutputConfiguration: {
            mediaType: "text/plain",
          },
          audioOutputConfiguration: {
            audioType: "SPEECH",
            encoding: "base64",
            sampleRate: 24000,
            bitDepth: 16,
            channelCount: 1,
            voiceId: "tiffany"
          },
          toolUseOutputConfiguration: {
            mediaType: "application/json"
          },
          toolConfiguration: {
            tools: [],
          }
        }
      }
    };

    this.addEventToQueue(promptStartEvent);
    this.session.isPromptStartSent = true;

    console.log(`Prompt start event sent for session ${this.sessionId}`);

    // Add a delay to ensure Nova Sonic processes the promptStart before we signal ready
    await new Promise(resolve => setTimeout(resolve, 1000));

    this.sendMessage({
      type: 'promptStartReady',
      message: 'Prompt start configured, ready for audio'
    });
  }

  /**
   * Adds an event to the session's processing queue.
   * @param event The event to add to the queue.
   */
  addEventToQueue(event: Record<string, unknown>) {
    if (!this.session) {
      console.error('Cannot add event to queue: session not initialized');
      return;
    }
    console.log(`Sending event to AWS: ${JSON.stringify(event, null, 2)}`);
    this.session.queue.push(event);
    this.session.queueSignal.next();
  }

  /**
   * Sets up and queues the system prompt events.
   */
  setupSystemPrompt(systemPromptContent?: string) {
    if (!this.session) {
      console.error('Session not initialized');
      return;
    }

    const systemPrompt = systemPromptContent || "You are a helpful and friendly assistant.";
    const contentName = `system-prompt-${this.session.promptName}`;

    const events = [
      {
        event: {
          contentStart: {
            promptName: this.session.promptName,
            contentName: contentName,
            type: 'TEXT',
            interactive: true,
            role: 'SYSTEM',
            textInputConfiguration: {
              mediaType: 'text/plain',
            },
          },
        },
      },
      {
        event: {
          textInput: {
            promptName: this.session.promptName,
            contentName: contentName,
            content: systemPrompt,
          },
        },
      },
      {
        event: {
          contentEnd: {
            promptName: this.session.promptName,
            contentName: contentName,
          },
        },
      },
    ];

    events.forEach(event => this.addEventToQueue(event));
    console.log(`System prompt events sent for session ${this.sessionId}`);
  }

  /**
   * Sets up and queues the contentStart event for audio input
   */
  setupContentStartEvent() {
    if (!this.session) {
      console.error('Session not initialized');
      return;
    }

    if (this.session.isContentStartSent) {
      console.log('Content start already sent');
      return;
    }

    const contentStartEvent = {
      event: {
        contentStart: {
          promptName: this.session.promptName,
          contentName: this.session.contentName,
          type: 'AUDIO',
          interactive: true,
          role: 'USER',
          audioInputConfiguration: {
            mediaType: 'audio/lpcm',
            encoding: 'pcm',
            sampleRate: 16000,
            bitDepth: 16,
          },
        },
      },
    };

    this.addEventToQueue(contentStartEvent);
    this.session.isContentStartSent = true;
    console.log(`Content start (AUDIO) event sent for session ${this.sessionId}`);
  }

  private createSessionAsyncIterable(): AsyncIterable<{ chunk: { bytes: Uint8Array } }> {
    if (!this.session) {
      throw new Error('Session not initialized');
    }

    const session = this.session;
    // Event count removed as it was unused

    return {
      [Symbol.asyncIterator]: async function* () {
        console.log('🔄 Starting async iterator for Nova Sonic events...');
        
        while (session.isActive) {
          while (session.queue.length > 0 && session.isActive) {
            const nextEvent = session.queue.shift();
            if (nextEvent) {
              yield {
                chunk: {
                  bytes: new TextEncoder().encode(JSON.stringify(nextEvent)),
                },
              };
            }
          }

          if (!session.isActive) break;

          await new Promise(resolve => {
            const timeout = setTimeout(() => {
              if (session.queue.length === 0) {
                // To prevent infinite loops if the queue remains empty
                // session.isActive = false; 
              }
              resolve(undefined);
            }, 100); // Poll every 100ms
            
            const originalNext = session.queueSignal.next;
            session.queueSignal.next = () => {
              clearTimeout(timeout);
              session.queueSignal.next = originalNext;
              resolve(undefined);
            };
          });
        }
        console.log('🔚 Queue is empty or session not active, ending iterator');
      },
    };
  }

  async processAudioChunk(base64Data: string | undefined, _sampleRate: number | undefined) {
    if (!this.session || !this.session.isActive) {
      console.warn('Session not ready, ignoring audio chunk');
      return;
    }

    if (!base64Data) {
      console.warn('No audio data provided');
      return;
    }

    try {
      // Send audio input event
      const audioInputEvent = {
        event: {
          audioInput: {
            promptName: this.session.promptName,
            contentName: this.session.contentName,
            content: base64Data
          }
        }
      };

      this.session.queue.push(audioInputEvent);
      this.session.queueSignal.next();

      // console.log(`🎤 Sent audio chunk to Nova Sonic session: ${this.sessionId}`); // Too noisy

    } catch (error) {
      console.error('Error processing audio chunk:', error);
      this.sendMessage({
        type: 'error',
        error: `Error processing audio: ${error instanceof Error ? error.message : 'Unknown error'}`
      });
    }
  }

  private async processResponseStream(response: { body?: AsyncIterable<{ chunk?: { bytes?: Uint8Array }; modelStreamErrorException?: unknown; internalServerException?: unknown }> }): Promise<void> {
    if (!this.session) return;

    try {
      console.log('🔄 Processing Nova Sonic response stream...');
      if (!response.body) {
        console.error('No response body from Nova Sonic');
        return;
      }
      for await (const event of response.body) {
        if (event.chunk?.bytes) {
          try {
            const textResponse = this.textDecoder.decode(event.chunk.bytes);
            const jsonResponse = JSON.parse(textResponse);
            await this.handleResponseEvent(jsonResponse);
          } catch (e: unknown) {
            console.error(`Error processing response chunk for session ${this.sessionId}:`, e);
          }
        } else if (event.modelStreamErrorException) {
          console.error(`Model stream error for session ${this.sessionId}:`, event.modelStreamErrorException);
          this.sendMessage({ type: 'error', error: 'An error occurred with the model stream.' });
          break;
        } else if (event.internalServerException) {
          console.error(`Internal server exception for session ${this.sessionId}:`, event.internalServerException);
          this.sendMessage({ type: 'error', error: 'An internal server error occurred.' });
          break;
        }
      }
    } catch (error: unknown) {
      console.error(`Error processing response stream for session ${this.sessionId}:`, error);
      this.sendMessage({ type: 'error', error: 'Failed to process the response stream.' });
    } finally {
      console.log('🔚 Response stream processing finished.');
      if (this.session) {
        this.session.isActive = false;
      }
    }
  }

  /**
   * Handles the response events from Nova Sonic.
   * It specifically looks for a `contentStart` event with `type: 'AUDIO'` from Nova Sonic.
   * a `contentStart` event with `type: 'AUDIO'` from Nova Sonic.
   */
  private async handleResponseEvent(jsonResponse: Record<string, unknown>) {
    try {
      if (jsonResponse.contentStart && typeof jsonResponse.contentStart === 'object') {
        // We no longer need to react to this from AWS, as we send our own.
        // This is just for logging now.
        const contentStart = jsonResponse.contentStart as { type?: string };
        if (contentStart.type === 'AUDIO') {
          console.log('ℹ️ Received contentStart (AUDIO) acknowledgement from Nova Sonic');
          this.sendMessage({ type: 'promptReady', message: 'Nova Sonic is ready for audio input' });
        }
      }

      if (jsonResponse.textOutput && typeof jsonResponse.textOutput === 'object') {
        const textOutput = jsonResponse.textOutput as { content?: string };
        if (textOutput.content) {
          this.sendMessage({
            type: 'final',
            text: textOutput.content,
            confidence: 1.0
          });
        }
      }

      if (jsonResponse.audioOutput && typeof jsonResponse.audioOutput === 'object') {
        console.log('Audio output received');
        // Handle audio output if needed
        const audioOutput = jsonResponse.audioOutput as { content?: string };
        if (audioOutput.content) {
          this.sendMessage({
            type: 'audio',
            audio: audioOutput.content,
          });
        }
      }

      if (jsonResponse.contentEnd) {
        console.log('📝 Content generation completed:', jsonResponse.contentEnd);
        this.sendMessage({
          type: 'final',
          message: 'Content generation completed'
        });
      }

      if (jsonResponse.streamComplete) {
        console.log('✅ Stream completed');
        this.sendMessage({
          type: 'stopped',
          message: 'Stream completed'
        });
      }
    } catch (error) {
      console.error('Error handling response event:', error);
    }
  }

  private handleModelError(error: { message?: string }) {
    console.error('Model stream error:', error);
    this.sendMessage({
      type: 'error',
      error: `Model error: ${error.message || 'Unknown model error'}`
    });
  }

  private handleServerError(error: { message?: string }) {
    console.error('Server error:', error);
    this.sendMessage({
      type: 'error',
      error: `Server error: ${error.message || 'Unknown server error'}`
    });
  }

  /**
   * Gracefully stops the bidirectional stream by sending end events.
   */
  async stopBidirectionalStream() {
    if (!this.session) {
      // Session is already stopped or was never started.
      return;
    }

    if (this.session.isActive) {
      console.log(`Gracefully stopping Nova Sonic stream for session ${this.sessionId}...`);

      // 1. End the audio content
      this.addEventToQueue({
        event: {
          contentEnd: {
            promptName: this.session.promptName,
            contentName: this.session.contentName,
          },
        },
      });

      // 2. End the prompt
      this.addEventToQueue({
        event: {
          promptEnd: {
            promptName: this.session.promptName,
          },
        },
      });
      
      // 3. End the session
      this.addEventToQueue({
        event: {
          sessionEnd: {},
        },
      });

      // Allow a moment for events to be sent before closing
      await new Promise(resolve => setTimeout(resolve, 500));
      
      this.session.isActive = false;
      this.session.closeSignal.next();
      this.session.closeSignal.complete();
    }
    this.session = null;

    this.sendMessage({
      type: 'stopped',
      message: 'Nova Sonic stream stopped gracefully'
    });

    console.log(`✅ Nova Sonic stream stopped for session ${this.sessionId}`);
  }
}

// Create and start the WebSocket server
const port = 8081;
const wss = new WebSocketServer({ port });

console.log('🎤 Nova Sonic WebSocket server started on ws://localhost:8081');
console.log('🚀 Nova Sonic WebSocket server is running with AWS SDK implementation!');
console.log('📡 Connect to: ws://localhost:8081');
console.log('🔧 Press Ctrl+C to stop');

wss.on('connection', (ws) => {
  console.log('New Nova Sonic WebSocket connection established');
  
  try {
    const handler = new NovaSDKHandler(ws);

    ws.on('message', async (data) => {
      try {
        await handler.handleMessage(data.toString());
      } catch (error) {
        console.error('Error handling WebSocket message:', error);
        ws.send(JSON.stringify({
          type: 'error',
          error: `Message handling error: ${error instanceof Error ? error.message : 'Unknown error'}`
        }));
      }
    });

    ws.on('close', () => {
      console.log('Nova Sonic WebSocket connection closed');
      handler.stopBidirectionalStream();
    });

    ws.on('error', (error) => {
      console.error('Nova Sonic WebSocket error:', error);
      handler.stopBidirectionalStream();
    });

  } catch (error) {
    console.error('Error creating Nova SDK handler:', error);
    ws.send(JSON.stringify({
      type: 'error',
      error: `Handler creation error: ${error instanceof Error ? error.message : 'Unknown error'}`
    }));
    ws.close();
  }
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n🛑 Shutting down Nova Sonic WebSocket server...');
  wss.close(() => {
    console.log('✅ Nova Sonic WebSocket server stopped');
    process.exit(0);
  });
});

process.on('SIGTERM', () => {
  console.log('\n🛑 Shutting down Nova Sonic WebSocket server...');
  wss.close(() => {
    console.log('✅ Nova Sonic WebSocket server stopped');
    process.exit(0);
  });
});