import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { loadSettings } from "@/lib/settings-store";

export async function GET() {
  // Try DB-backed flags first
  try {
    const cfg = await prisma.featureConfig.findUnique({ where: { id: 1 } });
    if (cfg) {
      const provider = cfg.asrProvider; // "TRANSCRIBE" | "NOVA_REALTIME" | "WEBSPEECH_FALLBACK"
      const failover = cfg.failoverMode; // "FIXED" | "AUTO_SWITCH"
      const language = cfg.language;
      // Back-compat key for older client function
      const asrWorkflow = provider === "NOVA_REALTIME" ? "NOVA_SONIC" : "TRANSCRIBE";
      return NextResponse.json({ provider, failover, language, asrWorkflow });
    }
  } catch {
    // ignore and fallback
  }
  // Fallback to file store
  const { asrWorkflow } = loadSettings();
  const provider = asrWorkflow === "NOVA_SONIC" ? "NOVA_REALTIME" : "TRANSCRIBE";
  // Prefer AUTO_SWITCH by default so we gracefully fall back to WebSpeech when
  // cloud ASR is unavailable in local/dev environments.
  const failover = "AUTO_SWITCH" as const;
  const language = "en-US";
  return NextResponse.json({ provider, failover, language, asrWorkflow });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { provider, failover, language } = body;

    // Validate input
    const validProviders = ["TRANSCRIBE", "NOVA_REALTIME", "WEBSPEECH_FALLBACK"];
    const validFailovers = ["FIXED", "AUTO_SWITCH"];
    
    if (!validProviders.includes(provider)) {
      return NextResponse.json({ error: "Invalid provider" }, { status: 400 });
    }
    
    if (!validFailovers.includes(failover)) {
      return NextResponse.json({ error: "Invalid failover mode" }, { status: 400 });
    }

    if (!language || typeof language !== "string") {
      return NextResponse.json({ error: "Invalid language" }, { status: 400 });
    }

    // Try to update the database
    try {
      await prisma.featureConfig.upsert({
        where: { id: 1 },
        update: {
          asrProvider: provider,
          failoverMode: failover,
          language: language,
          updatedAt: new Date()
        },
        create: {
          id: 1,
          asrProvider: provider,
          failoverMode: failover,
          language: language
        }
      });

      return NextResponse.json({ success: true, message: "Settings updated successfully" });
    } catch (dbError) {
      // If database is unavailable, return success but indicate it's temporary
      console.error("Failed to save ASR config to database:", dbError);
      return NextResponse.json({ 
        success: true, 
        message: "Settings updated (session only - database unavailable)",
        temporary: true
      });
    }
  } catch (error) {
    console.error("Error updating ASR config:", error);
    return NextResponse.json({ error: "Failed to update settings" }, { status: 500 });
  }
}
