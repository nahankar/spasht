export const dynamic = "force-dynamic";
import Link from "next/link";
import { prisma } from "@/lib/prisma";
import AnalyticsActions from "./AnalyticsActions";

function fmt(n: number | null | undefined) {
  return typeof n === "number" ? new Intl.NumberFormat().format(n) : "-";
}

function formatDuration(seconds: number | null | undefined) {
  if (!seconds || seconds === 0) return "-";
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return mins > 0 ? `${mins}m ${secs}s` : `${secs}s`;
}

function getSessionStatus(session: { overallScore: number | null; duration: number | null }) {
  if (session.overallScore !== null) {
    return { status: "Analyzed", color: "text-green-600 bg-green-50", icon: "✓" };
  }
  if (session.duration && session.duration > 0) {
    return { status: "Ready to Analyze", color: "text-blue-600 bg-blue-50", icon: "📊" };
  }
  return { status: "In Progress", color: "text-yellow-600 bg-yellow-50", icon: "⏳" };
}

export default async function AnalyticsPage() {
  const sessions = await prisma.interviewSession.findMany({
    orderBy: { startedAt: "desc" },
    take: 100,
    select: {
      id: true,
      startedAt: true,
      completedAt: true,
      duration: true,
      overallScore: true,
      fluencyScore: true,
      confidenceScore: true,
      clarityScore: true,
      speakingPace: true,
      transcription: true,
    },
  });

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-6 py-8 space-y-6">
        <header className="space-y-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Conversation Analytics</h1>
            <p className="text-gray-600 mt-2">
              Analyze your speech patterns, track improvement, and get personalized insights from your practice sessions.
            </p>
          </div>
          
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start">
              <div className="text-blue-600 mr-3">💡</div>
              <div>
                <h3 className="font-semibold text-blue-900">How to get started:</h3>
                <ol className="text-blue-800 text-sm mt-1 space-y-1">
                  <li>1. Complete a practice session in the <Link href="/practice" className="underline">Practice</Link> section</li>
                  <li>2. Click "Analyze" on any session below to generate comprehensive speech analysis</li>
                  <li>3. View detailed charts and insights by clicking on the Session ID</li>
                </ol>
              </div>
            </div>
          </div>
        </header>

        <div className="overflow-x-auto rounded-xl border">
          <table className="min-w-full text-sm">
            <thead className="bg-gray-50">
              <tr className="text-left">
                <th className="px-4 py-3 font-semibold text-gray-900">Session</th>
                <th className="px-4 py-3 font-semibold text-gray-900">Status</th>
                <th className="px-4 py-3 font-semibold text-gray-900">Started</th>
                <th className="px-4 py-3 font-semibold text-gray-900">Duration</th>
                <th className="px-4 py-3 font-semibold text-gray-900">Overall</th>
                <th className="px-4 py-3 font-semibold text-gray-900">Fluency</th>
                <th className="px-4 py-3 font-semibold text-gray-900">Clarity</th>
                <th className="px-4 py-3 font-semibold text-gray-900">Confidence</th>
                <th className="px-4 py-3 font-semibold text-gray-900">Pace (wpm)</th>
                <th className="px-4 py-3 font-semibold text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white">
              {sessions.map((s) => {
                const sessionStatus = getSessionStatus(s);
                return (
                  <tr key={s.id} className="border-t hover:bg-gray-50">
                    <td className="px-4 py-3 font-mono text-xs">
                      <Link 
                        href={`/analytics/${s.id}`} 
                        className="text-blue-600 hover:text-blue-800 underline hover:no-underline"
                      >
                        {s.id.substring(0, 8)}...
                      </Link>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${sessionStatus.color}`}>
                        <span className="mr-1">{sessionStatus.icon}</span>
                        {sessionStatus.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-gray-600">
                      {new Date(s.startedAt).toLocaleString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </td>
                    <td className="px-4 py-3">{formatDuration(s.duration)}</td>
                    <td className="px-4 py-3">
                      {s.overallScore ? (
                        <span className="font-semibold text-blue-600">{Math.round(s.overallScore)}/100</span>
                      ) : (
                        <span className="text-gray-400">-</span>
                      )}
                    </td>
                    <td className="px-4 py-3">{fmt(s.fluencyScore)}</td>
                    <td className="px-4 py-3">{fmt(s.clarityScore)}</td>
                    <td className="px-4 py-3">{fmt(s.confidenceScore)}</td>
                    <td className="px-4 py-3">{fmt(s.speakingPace)}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <AnalyticsActions sessionId={s.id} hasAnalysis={!!s.overallScore} />
                        <Link 
                          className="text-xs text-gray-500 hover:text-gray-700 underline" 
                          href={`/api/sessions/${s.id}/analysis`} 
                          target="_blank"
                        >
                          JSON
                        </Link>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {sessions.length === 0 && (
                <tr>
                  <td colSpan={10} className="px-4 py-12 text-center">
                    <div className="text-gray-500">
                      <div className="text-4xl mb-2">📊</div>
                      <h3 className="text-lg font-semibold text-gray-700 mb-1">No sessions yet</h3>
                      <p className="text-sm">Start practicing to see your analytics here!</p>
                      <Link 
                        href="/practice" 
                        className="inline-block mt-3 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                      >
                        Start Practice Session
                      </Link>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

