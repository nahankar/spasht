"use client";
import React from "react";
import { AudioRecorder } from "@/components/media/AudioRecorder";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { NudgePopup, type NudgeType } from "@/components/nudge-popup";
import { ChatInterface, type ChatMessage } from "@/components/ui/chat-interface";
import { getAsrProvider } from "@/core/asr/factory";
import type { AsrProvider } from "@/core/asr/types";
import type { AsrTranscript } from "@/core/asr/types";
import { startSession, endSession, logSessionEvent } from "@/lib/session-client";
import type { AsrState } from "@/components/media/AudioRecorder";

type ConversationState = 'waiting_for_user' | 'user_speaking' | 'waiting_for_ai' | 'ai_responding';

interface ConversationMessagePayload {
  role: 'USER' | 'ASSISTANT';
  content: string;
  conversationState: ConversationState;
  confidence?: number;
  provider?: string;
  isInterrupted?: boolean;
  audioUrl?: string;
  audioMetadata?: {
    duration?: number;
    sampleRate?: number;
    size?: number;
  };
}

export default function PracticePage() {
  const [providerName, setProviderName] = React.useState<string>("loading…");
  const [sessionId, setSessionId] = React.useState<string | null>(null);
  const [nudge, setNudge] = React.useState<{ show: boolean; msg: string; type: NudgeType }>(
    { show: false, msg: "", type: "pace" }
  );
  const [liveText, setLiveText] = React.useState<string>("");
  const [chatMessages, setChatMessages] = React.useState<ChatMessage[]>([]);
  const [enableLogging, setEnableLogging] = React.useState<boolean>(false);
  const currentMessageIdRef = React.useRef<string | null>(null);
  const messageCounterRef = React.useRef<number>(0);
  const lastProcessedTextRef = React.useRef<string>('');
  const conversationStateRef = React.useRef<ConversationState>('waiting_for_user');
  const [recorderState, setRecorderState] = React.useState<AsrState>('idle');
  const expectingUserInputRef = React.useRef<boolean>(false);
  const lastUserInputTimeRef = React.useRef<number>(0);

  // Conversation logging function
  const logConversationMessage = React.useCallback(async (payload: ConversationMessagePayload) => {
    if (!enableLogging) {
      console.log('📝 Database logging disabled - skipping message log');
      return;
    }
    
    if (!sessionId) {
      console.warn('⚠️ Cannot log conversation message - no active session');
      return;
    }

    try {
      const eventType = payload.role === 'USER' ? 'user_message' : 'ai_message';
      
      await logSessionEvent(sessionId, eventType, {
        ...payload,
        timestamp: new Date().toISOString(),
        messageIndex: messageCounterRef.current,
      });
      
      console.log(`📝 Logged ${payload.role} message to database:`, {
        sessionId,
        type: eventType,
        contentPreview: payload.content.substring(0, 50) + (payload.content.length > 50 ? '...' : ''),
        state: payload.conversationState
      });
    } catch (error) {
      console.error('❌ Failed to log conversation message:', error);
      // Don't throw - logging failure shouldn't break the conversation flow
    }
  }, [sessionId, enableLogging]);
  
  const dismiss = () => setNudge((n) => ({ ...n, show: false }));
  const nudgeTimeout = React.useRef<number | null>(null);
  const lastCoachCallAt = React.useRef<number>(0);

  const showNudge = React.useCallback((msg: string, type: NudgeType) => {
    setNudge({ show: true, msg, type });
    if (nudgeTimeout.current) window.clearTimeout(nudgeTimeout.current);
    nudgeTimeout.current = window.setTimeout(() => setNudge((p) => ({ ...p, show: false })), 3000);
  }, []);

  const handleAmplitude = React.useCallback((level: number) => {
    // Simple heuristics: low volume → speak up; clipping unlikely here
    if (level < 0.02) showNudge("Speak a bit louder for clarity", "volume");
  }, [showNudge]);

  React.useEffect(() => {
  fetch("/api/config/asr", { cache: "no-store" })
      .then((r) => r.json())
      .then((d) => setProviderName(String(d?.provider || d?.asrWorkflow || "unknown")))
      .catch(() => setProviderName("unknown"));
  }, []);

  const handleTranscript = React.useCallback((text: string, meta?: AsrTranscript) => {
    
    // Skip duplicate texts to prevent message duplication
    if (text === lastProcessedTextRef.current && meta?.isFinal) {
      return;
    }
    
    // Update last processed text for final messages
    if (meta?.isFinal) {
      lastProcessedTextRef.current = text;
    }
    
      // Check if this is a Nova Sonic interruption signal (JSON format, not regular text)
      // Only treat as interruption if it's a pure JSON signal, not mixed content
      const isJsonInterruptSignal = text.trim() === '{ "interrupted" : true }' || text.trim() === '{"interrupted": true}';
      
      if (isJsonInterruptSignal) {
        console.log(`🔇 ⚡ BARGE-IN: JSON interruption signal detected at ${new Date().toLocaleTimeString()}.${Date.now() % 1000}`);
      // Mark current message as interrupted and reset state
      if (currentMessageIdRef.current) {
        setChatMessages(prev => 
          prev.map(msg => 
            msg.id === currentMessageIdRef.current 
              ? { ...msg, isInterrupted: true }
              : msg
          )
        );
        
        // Log the interruption event
        logConversationMessage({
          role: 'ASSISTANT',
          content: text,
          conversationState: conversationStateRef.current,
          confidence: meta?.confidence,
          provider: providerName,
          isInterrupted: true
        });
      }
      currentMessageIdRef.current = null;
      conversationStateRef.current = 'waiting_for_user';
      return;
    }
    
    // SERVER-DRIVEN message classification (following reference app approach)
    const serverRole = meta?.role; // 'USER' or 'ASSISTANT' from server
    
    // Handle USER messages
    if (serverRole === 'USER' && meta?.isFinal && text.trim()) {
      
      messageCounterRef.current += 1;
      const userMessage: ChatMessage = {
        id: `user-${Date.now()}-${messageCounterRef.current}`,
        type: 'user',
        content: text,
        timestamp: new Date(),
      };
      
      setChatMessages(prev => {
        // Check if this exact message already exists to prevent duplicates
        const messageExists = prev.some(msg => 
          msg.content === userMessage.content && 
          msg.type === 'user' && 
          Math.abs(msg.timestamp.getTime() - userMessage.timestamp.getTime()) < 5000
        );
        
        if (messageExists) {
          return prev;
        }
        
        return [...prev, userMessage];
      });
      
      // Log user message to database
      logConversationMessage({
        role: 'USER',
        content: text,
        conversationState: conversationStateRef.current,
        confidence: meta?.confidence,
        provider: providerName
      });
      
      // Transition state to wait for AI response and prepare for AI message
      conversationStateRef.current = 'waiting_for_ai';
      const nextAiCounter = messageCounterRef.current + 1;
      currentMessageIdRef.current = `ai-${Date.now()}-${nextAiCounter}`;
      
      return;
    }
    
      // Handle ASSISTANT messages - REFERENCE APP EXACT MATCH
      if (serverRole === 'ASSISTANT' && text.trim()) {
        
        setChatMessages(prev => {
          const lastMessage = prev[prev.length - 1];
          
          if (lastMessage && lastMessage.type === 'assistant') {
            // Check for duplicate content to prevent Nova Sonic duplication
            const trimmedText = text.trim();
            const lastContent = lastMessage.content.trim();
            
            // If the new text is already contained in the last message, skip it
            if (lastContent.includes(trimmedText)) {
              return prev;
            }
            
            // Same role, append to the last turn (EXACT reference app logic)
            return prev.map((msg, index) => 
              index === prev.length - 1 
                ? { ...msg, content: msg.content + ' ' + text, timestamp: new Date() }
                : msg
            );
          } else {
            // Different role, add a new turn (EXACT reference app logic)
            messageCounterRef.current += 1;
            const messageId = `ai-${Date.now()}-${messageCounterRef.current}`;
            
            const aiMessage: ChatMessage = {
            id: messageId,
            type: 'assistant',
            content: text,
            timestamp: new Date(),
          };
          return [...prev, aiMessage];
        }
      });
      
      // Log only final AI messages to database
      if (meta?.isFinal) {
        logConversationMessage({
          role: 'ASSISTANT',
          content: text,
          conversationState: conversationStateRef.current,
          confidence: meta?.confidence,
          provider: providerName,
          isInterrupted: false
        });
        
        // AI turn is over, reset for next user input
        conversationStateRef.current = 'waiting_for_user';
      } else {
        // Ensure we are in the 'ai_responding' state for partial messages
        if (conversationStateRef.current === 'waiting_for_ai') {
          conversationStateRef.current = 'ai_responding';
          console.log(`🔄 State transition: -> ai_responding`);
        }
      }
      
      return;
    }
    
    // Fallback for messages without server role (backward compatibility)
    if (!serverRole && meta?.isFinal && text.trim()) {
      const isFirstMessage = chatMessages.length === 0;
      if (conversationStateRef.current === 'waiting_for_user' || isFirstMessage) {
        console.log(`👤 USER message (fallback - no server role):`, { text });
        
        messageCounterRef.current += 1;
        const userMessage: ChatMessage = {
          id: `user-${Date.now()}-${messageCounterRef.current}`,
          type: 'user',
          content: text,
          timestamp: new Date(),
        };
        
        setChatMessages(prev => [...prev, userMessage]);
        
        logConversationMessage({
          role: 'USER',
          content: text,
          conversationState: conversationStateRef.current,
          confidence: meta?.confidence,
          provider: providerName
        });
        
        conversationStateRef.current = 'waiting_for_ai';
        const nextAiCounter = messageCounterRef.current + 1;
        currentMessageIdRef.current = `ai-${Date.now()}-${nextAiCounter}`;
        
        return;
      } else {
        console.warn('⚠️ No server role provided for message, ignoring:', { text, meta });
        return;
      }
    }

    const lower = text.toLowerCase();
    const fillers = ["um", "uh", "like ", "you know", "basically", "actually"];
    if (fillers.some((f) => lower.includes(f))) {
      showNudge("Try reducing filler words", "filler");
      if (sessionId) logSessionEvent(sessionId, "nudge", { type: "filler", message: "Try reducing filler words" }).catch(() => {});
    }
    const words = lower.trim().split(/\s+/).filter(Boolean);
    // Very naive pace check: >150 wpm equivalent if >25 words in 10s chunk (not exact here)
    if (words.length > 25) {
      showNudge("Slow down a touch for clarity", "pace");
      if (sessionId) logSessionEvent(sessionId, "nudge", { type: "pace", message: "Slow down a touch for clarity" }).catch(() => {});
    }

    // ASR latency metric (approx): now minus provider event timestamp
    if (sessionId && meta?.timestamp) {
      const latency = Math.max(0, Date.now() - meta.timestamp);
      logSessionEvent(sessionId, "metric", { name: "asr_latency_ms", value: latency, isFinal: !!meta.isFinal }).catch(() => {});
    }

    // Call server coach for smarter nudges (throttled)
    const now = Date.now();
    if (now - lastCoachCallAt.current > 1500 && text.trim().length > 12) {
      lastCoachCallAt.current = now;
      // Estimate simple filler count in the snippet
      const fillerCount = fillers.reduce((acc, f) => acc + (lower.includes(f) ? 1 : 0), 0);
      const coachStart = Date.now();
      fetch("/api/coach/nudges", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, fillerCount, timestamp: now }),
      })
        .then(async (r) => (r.ok ? r.json() : Promise.reject(await r.json())))
        .then((data) => {
          // Coach latency metric
          if (sessionId) {
            const coachLatency = Math.max(0, Date.now() - coachStart);
            logSessionEvent(sessionId, "metric", { name: "coach_latency_ms", value: coachLatency }).catch(() => {});
          }
          const first = data?.nudges?.[0];
          if (first?.message && first?.type) {
            showNudge(String(first.message), String(first.type) as NudgeType);
            if (sessionId) logSessionEvent(sessionId, "nudge", first).catch(() => {});
          }
        })
        .catch(() => {
          // silent fail for UX; consider logging later
        });
    }
  }, [showNudge, sessionId]);

  // Wire ASR provider to emit transcripts to our nudge logic
  const asrRef = React.useRef<AsrProvider | null>(null);

  const ensureAsrStarted = React.useCallback(async (forceRestart = false) => {
    if (asrRef.current && !forceRestart) {
      return;
    }
    
    if (forceRestart && asrRef.current) {
      // Reset the audioStart flag for barge-in without restarting the ASR
      if ('resetForNewTurn' in asrRef.current) {
        (asrRef.current as any).resetForNewTurn();
        return;
      }
    }
    const asr = await getAsrProvider();
    asr.onPartial((t) => { setLiveText(t.text); handleTranscript(t.text, t); });
    asr.onFinal((t) => { setLiveText(t.text); handleTranscript(t.text, t); });
    
    // CRITICAL: Handle barge-in events for immediate state transition
    if (asr.onBargeIn) {
      asr.onBargeIn(() => {
        console.log(`🔔 BARGE-IN CALLBACK at ${new Date().toLocaleTimeString()}.${Date.now() % 1000}: Transitioning from ai_responding -> user_speaking`);
        conversationStateRef.current = 'user_speaking';
        setRecorderState('listening');
        
        // Clear any active AI message since it was interrupted
        currentMessageIdRef.current = null;
      });
    }
    
    try { 
      await asr.start(); 
    } catch (err) { 
      console.error("ASR failed to start:", (err as Error)?.message || err); 
    }
    asrRef.current = asr;
  }, [handleTranscript]);

  // Link recorder state to our conversation state machine
  React.useEffect(() => {
    if (recorderState === 'listening') {
      const previousState = conversationStateRef.current;
      
      // BARGE-IN DETECTION: If user starts speaking while AI is responding
      if (previousState === 'ai_responding') {
        
        // Mark current AI message as interrupted
        if (currentMessageIdRef.current) {
          setChatMessages(prev => 
            prev.map(msg => 
              msg.id === currentMessageIdRef.current 
                ? { ...msg, isInterrupted: true }
                : msg
            )
          );
          console.log(`🔇 Marked message ${currentMessageIdRef.current} as interrupted`);
          
          // Log the barge-in interruption event
          logConversationMessage({
            role: 'ASSISTANT',
            content: '[INTERRUPTED BY BARGE-IN]',
            conversationState: previousState,
            provider: providerName,
            isInterrupted: true
          });
        }
        
        // Clear current AI message tracking
        currentMessageIdRef.current = null;
      }
      
      // Transition to user speaking (regardless of previous state)
      conversationStateRef.current = 'user_speaking';
      expectingUserInputRef.current = true; // User is about to speak
      
      // Start the ASR provider (Nova Sonic) when user starts speaking
      // Force restart during barge-in to ensure proper state transition
      const shouldForceRestart = previousState === 'ai_responding';
      ensureAsrStarted(shouldForceRestart).catch(err => {
        console.error('Failed to start ASR provider:', err);
      });
      
    } else if (recorderState === 'idle' && conversationStateRef.current === 'user_speaking') {
      // User has stopped talking, but we haven't received the final transcript yet.
      // The handleTranscript function will transition to 'waiting_for_ai'
      console.log(`🎤 Recorder is idle. Awaiting final transcript.`);
    }
  }, [recorderState, ensureAsrStarted]);

  // Removed unused stopAsr function - ASR lifecycle is now managed automatically

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-6 py-8">
        <header className="mb-6">
          <h1 className="text-2xl font-semibold">Practice Session</h1>
          <p className="text-muted-foreground">Speak naturally. We'll listen and nudge you gently.</p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Column - Microphone Controls */}
          <Card>
            <CardHeader>
              <CardTitle>Microphone</CardTitle>
              <CardDescription>
                <span className="inline-flex items-center gap-2 text-xs">
                  <span>ASR Provider</span>
                  <Badge variant="secondary">{providerName}</Badge>
                </span>
              </CardDescription>
              <div className="px-6 pb-2">
                <label className="inline-flex items-center gap-2 text-xs cursor-pointer text-muted-foreground">
                  <input
                    type="checkbox"
                    checked={enableLogging}
                    onChange={(e) => setEnableLogging(e.target.checked)}
                    className="w-3 h-3 rounded border-gray-300"
                  />
                  <span>Enable conversation logging to database</span>
                </label>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center gap-6">
                <div
                  className="w-24 h-24 rounded-full shadow-inner flex items-center justify-center"
                  style={{ background: "radial-gradient(circle at 30% 30%, hsl(240 100% 97%), hsl(270 100% 97%))" }}
                  aria-hidden
                >
                  <span className="text-primary font-semibold">🎤</span>
                </div>
                <AudioRecorder
                  autoStart={false}
                  useWebSpeechFallback={false}
                  onAmplitude={handleAmplitude}
                  onPartial={handleTranscript}
                  onFinal={handleTranscript}
                  onStateChange={setRecorderState}
                  recorderState={recorderState}
                />
                <div className="w-full text-sm text-muted-foreground max-w-xl">
                  <div className="font-medium mb-1 text-foreground">Live Transcript</div>
                  <div className="rounded-md border p-3 min-h-[48px] whitespace-pre-wrap break-words">{liveText || "…"}</div>
                </div>
                <p className="text-sm text-muted-foreground">Tip: Pause briefly after key points.</p>
              </div>
            </CardContent>
          </Card>

          {/* Right Column - Chat Interface */}
          <Card className="h-[600px]">
            <ChatInterface messages={chatMessages} className="h-full" />
          </Card>
        </div>
      </div>

      <NudgePopup show={nudge.show} message={nudge.msg} type={nudge.type} onDismiss={dismiss} />
    </div>
  );
}
